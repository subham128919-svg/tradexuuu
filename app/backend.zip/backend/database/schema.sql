-- ─────────────────────────────────────────────────────────────────
--  TradingApp — MySQL Schema
--  Run via phpMyAdmin OR command line:
--    mysql -u tradingapp -p tradingapp < schema.sql
-- ─────────────────────────────────────────────────────────────────

CREATE DATABASE IF NOT EXISTS tradingapp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE tradingapp;

-- Users
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  kite_user_id  VARCHAR(100) UNIQUE NOT NULL,
  email         VARCHAR(255),
  name          VARCHAR(255),
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Watchlist
CREATE TABLE IF NOT EXISTS watchlist (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    VARCHAR(100) NOT NULL,
  symbol     VARCHAR(50) NOT NULL,
  exchange   VARCHAR(10) NOT NULL DEFAULT 'NSE',
  list_name  VARCHAR(100) NOT NULL DEFAULT 'My list 1',
  position   INT DEFAULT 0,
  added_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_watch (user_id, symbol, exchange, list_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE INDEX IF NOT EXISTS idx_watchlist_user ON watchlist(user_id);

-- GTT Orders
CREATE TABLE IF NOT EXISTS gtt_orders (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  user_id       VARCHAR(100) NOT NULL,
  symbol        VARCHAR(50) NOT NULL,
  exchange      VARCHAR(10) NOT NULL,
  trigger_type  VARCHAR(20) NOT NULL,
  trigger_price DECIMAL(15,2),
  order_type    VARCHAR(10),
  quantity      INT,
  status        VARCHAR(20) DEFAULT 'ACTIVE',
  valid_till    DATE,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_gtt_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MF Holdings
CREATE TABLE IF NOT EXISTS mf_holdings (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  user_id       VARCHAR(100) NOT NULL,
  scheme_code   VARCHAR(20) NOT NULL,
  scheme_name   VARCHAR(255) NOT NULL,
  units         DECIMAL(15,4),
  avg_nav       DECIMAL(15,4),
  invested_amt  DECIMAL(15,2),
  current_nav   DECIMAL(15,4),
  current_value DECIMAL(15,2),
  xirr          DECIMAL(10,4),
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_mf (user_id, scheme_code),
  INDEX idx_mf_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- SIPs
CREATE TABLE IF NOT EXISTS sips (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  user_id           VARCHAR(100) NOT NULL,
  scheme_code       VARCHAR(20) NOT NULL,
  scheme_name       VARCHAR(255) NOT NULL,
  amount            DECIMAL(15,2) NOT NULL,
  frequency         VARCHAR(20) DEFAULT 'monthly',
  day_of_month      INT,
  installments_done INT DEFAULT 0,
  status            VARCHAR(20) DEFAULT 'ACTIVE',
  next_debit        DATE,
  started_at        DATE,
  created_at        DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sip_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Price Alerts
CREATE TABLE IF NOT EXISTS price_alerts (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      VARCHAR(100) NOT NULL,
  symbol       VARCHAR(50) NOT NULL,
  exchange     VARCHAR(10) NOT NULL DEFAULT 'NSE',
  `condition`  VARCHAR(10) NOT NULL,
  target_price DECIMAL(15,2) NOT NULL,
  is_triggered TINYINT(1) DEFAULT 0,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_alert_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
