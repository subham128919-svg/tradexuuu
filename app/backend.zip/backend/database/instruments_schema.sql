-- Instruments table — synced once daily from Zerodha's instrument dump
-- Enables real search (LIKE query) instead of hitting Kite's API per keystroke
USE tradex;

CREATE TABLE IF NOT EXISTS instruments (
  instrument_token BIGINT PRIMARY KEY,
  tradingsymbol     VARCHAR(50)  NOT NULL,
  name              VARCHAR(255) NOT NULL,
  exchange          VARCHAR(10)  NOT NULL,
  segment           VARCHAR(20),
  updated_at        DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_symbol (tradingsymbol),
  INDEX idx_name (name),
  FULLTEXT INDEX idx_search (tradingsymbol, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
