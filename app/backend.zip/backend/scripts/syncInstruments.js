// scripts/syncInstruments.js
// Downloads Zerodha's full instrument list ONCE and stores it in MySQL.
// Run manually first time:   node scripts/syncInstruments.js
// Then schedule via cron to run daily (instrument tokens rarely change,
// but running daily is safe and cheap):
//   crontab -e
//   0 7 * * * cd /var/www/tradingapp && node scripts/syncInstruments.js >> logs/sync.log 2>&1
require('dotenv').config();
const { KiteConnect } = require('kiteconnect');
const mysql = require('mysql2/promise');

async function main() {
  console.log('Connecting to MySQL...');
  const db = await mysql.createConnection({
    host: process.env.DB_HOST, port: process.env.DB_PORT,
    user: process.env.DB_USER, password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
  });

  console.log('Connecting to Kite...');
  const kite = new KiteConnect({ api_key: process.env.KITE_API_KEY });

  // Get access token — must have logged in today via /api/v1/auth/kite-login
  const Redis = require('ioredis');
  const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');
  const token = await redis.get('kite:access_token');
  if (!token) {
    console.error('No Kite access token found. Log in first: https://tradingstock.online/api/v1/auth/kite-login');
    process.exit(1);
  }
  kite.setAccessToken(token);

  console.log('Downloading NSE instruments (this can take 20-40 seconds)...');
  const nseInstruments = await kite.getInstruments(['NSE']);
  console.log(`Got ${nseInstruments.length} NSE instruments`);

  console.log('Downloading BSE instruments...');
  const bseInstruments = await kite.getInstruments(['BSE']);
  console.log(`Got ${bseInstruments.length} BSE instruments`);

  const all = [...nseInstruments, ...bseInstruments]
    // Keep only equities and indices — skip futures/options to keep table small & relevant
    .filter(i => i.segment === 'NSE' || i.segment === 'BSE' || i.segment === 'INDICES');

  console.log(`Inserting ${all.length} instruments into MySQL...`);

  // Clear old data, bulk insert new — chunked to avoid one giant query
  await db.query('TRUNCATE TABLE instruments');
  const CHUNK = 500;
  for (let i = 0; i < all.length; i += CHUNK) {
    const chunk = all.slice(i, i + CHUNK);
    const values = chunk.map(x => [
      x.instrument_token, x.tradingsymbol, x.name || x.tradingsymbol, x.exchange, x.segment
    ]);
    await db.query(
      'INSERT IGNORE INTO instruments (instrument_token, tradingsymbol, name, exchange, segment) VALUES ?',
      [values]
    );
    process.stdout.write(`\r  ${Math.min(i + CHUNK, all.length)}/${all.length}`);
  }

  console.log('\nDone! Instruments synced successfully.');
  await db.end();
  process.exit(0);
}

main().catch(err => {
  console.error('Sync failed:', err.message);
  process.exit(1);
});
