// marketDataService.js
// Central "smart quotes" logic used by BOTH the REST /market/quotes
// route and the WebSocket broadcast loop, so there is exactly one place
// that decides when to call Kite vs. serve cache.
//
// Behavior:
//   Market OPEN   -> serve cache if fresher than LIVE_POLL_STALE_MS,
//                     otherwise fetch fresh from Kite and update cache.
//   Market CLOSED -> serve cache only. Only calls Kite for a symbol
//                     that has NEVER been cached at all (first-ever
//                     view of that stock) -- everything else is served
//                     from the last known tick, zero Kite API calls.
//
// This is what "never show blank + save API quota after hours" means
// in practice.
const kite            = require('./kiteService');
const tickCache        = require('./tickCache');
const { getMarketStatus } = require('./marketStatusService');
const { logger }       = require('../config/logger');

const LIVE_POLL_STALE_MS = 3000;

async function getQuotesSmart(symbols) {
  const status = getMarketStatus();
  const cached = await tickCache.getTicks(symbols);
  const now    = Date.now();

  const needsFresh = status.isOpen
    ? symbols.filter(s => !cached[s] || (now - new Date(cached[s].updatedAt).getTime()) > LIVE_POLL_STALE_MS)
    : symbols.filter(s => !cached[s]); // closed: only ever-uncached symbols hit Kite

  if (needsFresh.length > 0) {
    try {
      const fresh = await kite.getQuotes(needsFresh);
      for (const [sym, q] of Object.entries(fresh)) {
        const tick = {
          symbol:    sym,
          ltp:       q.last_price,
          open:      q.ohlc?.open  || 0,
          high:      q.ohlc?.high  || 0,
          low:       q.ohlc?.low   || 0,
          close:     q.ohlc?.close || 0,
          change:    q.net_change  || 0,
          changePct: parseFloat(((q.net_change / (q.ohlc?.close || 1)) * 100).toFixed(2)),
          volume:    q.volume_traded || 0,
          updatedAt: new Date().toISOString(),
        };
        await tickCache.setTick(sym, tick);
        cached[sym] = tick;
      }
    } catch (err) {
      logger.warn('getQuotesSmart: Kite fetch failed, serving cache only -- ' + err.message);
      // Fall through -- whatever's already in `cached` (possibly partial
      // or stale) is still returned. Never throw here; the caller should
      // always get SOMETHING if anything was ever cached.
    }
  }

  return { ticks: cached, marketStatus: status };
}

module.exports = { getQuotesSmart };
