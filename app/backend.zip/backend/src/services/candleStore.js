// candleStore.js
// DB-first candle storage. Charts load from MySQL first; Kite is only
// called when the DB doesn't have fresh-enough data for the requested
// range, and every Kite fetch immediately persists into the DB so the
// next request (yours or anyone else's) never needs Kite again for
// that range.
//
// Freshness rule:
//   - Intraday intervals (5minute, 30minute) must be from TODAY to be
//     considered fresh -- otherwise refetch.
//   - Daily/weekly intervals are considered fresh if the last stored
//     candle is within 1 day of the requested end date.
const db     = require('../config/database');
const kite   = require('./kiteService');
const { logger } = require('../config/logger');

function periodToKite(period) {
  const now  = new Date();
  const fmt  = d => d.toISOString().split('T')[0];
  const ago  = (days) => { const d = new Date(now); d.setDate(d.getDate() - days); return fmt(d); };
  const agoM = (m)    => { const d = new Date(now); d.setMonth(d.getMonth() - m);  return fmt(d); };
  const agoY = (y)    => { const d = new Date(now); d.setFullYear(d.getFullYear() - y); return fmt(d); };
  switch (period) {
    case '1D': return { interval: '5minute',  from: ago(1),  to: fmt(now) };
    case '1W': return { interval: '30minute', from: ago(7),  to: fmt(now) };
    case '1M': return { interval: 'day',      from: agoM(1), to: fmt(now) };
    case '3M': return { interval: 'day',      from: agoM(3), to: fmt(now) };
    case '1Y': return { interval: 'day',      from: agoY(1), to: fmt(now) };
    case '5Y': return { interval: 'week',     from: agoY(5), to: fmt(now) };
    default:   return { interval: 'day',      from: agoM(1), to: fmt(now) };
  }
}

function rowsToCandles(rows) {
  return rows.map(r => ({
    time:   Math.floor(new Date(r.candle_time).getTime() / 1000),
    open:   parseFloat(r.open), high: parseFloat(r.high),
    low:    parseFloat(r.low),  close: parseFloat(r.close),
    volume: r.volume,
  }));
}

async function getCandles(symbol, period) {
  const { interval, from, to } = periodToKite(period);

  const { rows } = await db.query(
    'SELECT candle_time, open, high, low, close, volume FROM candles ' +
    'WHERE symbol = ? AND `interval` = ? AND candle_time BETWEEN ? AND ? ' +
    'ORDER BY candle_time ASC',
    [symbol, interval, from + ' 00:00:00', to + ' 23:59:59']
  );

  const hasData         = rows.length > 0;
  const lastCandleDate   = hasData ? new Date(rows[rows.length - 1].candle_time) : null;
  const toDate            = new Date(to);
  const staleDays         = lastCandleDate ? (toDate - lastCandleDate) / 86400000 : Infinity;
  const isIntraday        = interval === '5minute' || interval === '30minute';
  const maxStaleDays       = isIntraday ? 0 : 1;

  if (hasData && staleDays <= maxStaleDays) {
    return rowsToCandles(rows);
  }

  // DB stale or empty -- fetch from Kite and persist.
  try {
    const [exchange, sym] = symbol.split(':');
    const token   = await kite.getInstrumentToken(exchange, sym);
    const candles = await kite.getCandles(token, interval, from, to);
    await storeCandles(symbol, interval, candles);
    return candles;
  } catch (err) {
    logger.warn('candleStore: Kite fetch failed for ' + symbol + ' -- ' + err.message);
    // Kite failed too (e.g. token expired) -- serve whatever's in the DB,
    // even if stale, rather than an empty chart.
    if (hasData) return rowsToCandles(rows);
    throw err; // truly nothing available anywhere
  }
}

async function storeCandles(symbol, interval, candles) {
  if (!candles.length) return;
  const CHUNK = 200;
  for (let i = 0; i < candles.length; i += CHUNK) {
    const chunk  = candles.slice(i, i + CHUNK);
    const values = chunk.map(c => [
      symbol, interval, new Date(c.time * 1000), c.open, c.high, c.low, c.close, c.volume
    ]);
    await db.query(
      'INSERT INTO candles (symbol, `interval`, candle_time, open, high, low, close, volume) VALUES ? ' +
      'ON DUPLICATE KEY UPDATE open=VALUES(open), high=VALUES(high), low=VALUES(low), close=VALUES(close), volume=VALUES(volume)',
      [values]
    );
  }
}

module.exports = { getCandles, storeCandles, periodToKite };
