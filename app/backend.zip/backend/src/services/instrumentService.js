// instrumentService.js — fast search using the synced instruments table
// Populated by scripts/syncInstruments.js — run that once before search works.
const db = require('../config/database');

async function searchInstruments(query, exchange) {
  if (!query || query.trim().length < 1) return [];

  const like = `%${query.trim()}%`;
  const params = exchange
    ? [like, like, exchange, 20]
    : [like, like, 20];

  const exchangeFilter = exchange ? 'AND exchange = ?' : '';

  const { rows } = await db.query(
    `SELECT instrument_token, tradingsymbol, name, exchange
     FROM instruments
     WHERE (tradingsymbol LIKE ? OR name LIKE ?) ${exchangeFilter}
     ORDER BY
       CASE WHEN tradingsymbol = ? THEN 0
            WHEN tradingsymbol LIKE ? THEN 1
            ELSE 2 END,
       LENGTH(tradingsymbol)
     LIMIT ?`,
    exchange
      ? [like, like, exchange, query.trim().toUpperCase(), `${query.trim().toUpperCase()}%`, 20]
      : [like, like, query.trim().toUpperCase(), `${query.trim().toUpperCase()}%`, 20]
  );

  return rows.map(r => ({
    symbol:          r.tradingsymbol,
    name:            r.name,
    exchange:        r.exchange,
    instrumentToken: r.instrument_token,
  }));
}

module.exports = { searchInstruments };
