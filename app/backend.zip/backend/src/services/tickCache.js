// tickCache.js
// Redis-backed "last known tick" store. No TTL by design -- last known
// truth for a symbol persists forever until overwritten.
//
// FIX: self-healing normalization on read. Ticks written before the
// updatedAt-format fix are permanently stuck in Redis with an ISO
// date string (e.g. "2026-08-07T08:18:19.890Z") instead of a numeric
// epoch. Since these never expire, they'd keep crashing the Android
// client forever. Every read now coerces updatedAt to a number,
// self-healing old bad entries the next time anyone touches them --
// no manual Redis flush required.
const redis = require('../config/redis');

const KEY_PREFIX = 'tick:';

function normalizeTick(tick) {
  if (!tick) return tick;
  if (typeof tick.updatedAt !== 'number' || Number.isNaN(tick.updatedAt)) {
    tick.updatedAt = Date.now();
  }
  return tick;
}

async function setTick(symbol, tick) {
  try {
    tick.updatedAt = typeof tick.updatedAt === 'number' ? tick.updatedAt : Date.now();
    await redis.set(KEY_PREFIX + symbol, JSON.stringify(tick));
  } catch { /* non-fatal */ }
}

async function getTick(symbol) {
  try {
    const raw = await redis.get(KEY_PREFIX + symbol);
    if (!raw) return null;
    const tick = normalizeTick(JSON.parse(raw));
    // Re-persist the healed version so this symbol never needs healing again
    redis.set(KEY_PREFIX + symbol, JSON.stringify(tick)).catch(() => {});
    return tick;
  } catch {
    return null;
  }
}

async function getTicks(symbols) {
  const result = {};
  for (const sym of symbols) {
    const t = await getTick(sym);
    if (t) result[sym] = t;
  }
  return result;
}

module.exports = { setTick, getTick, getTicks };
