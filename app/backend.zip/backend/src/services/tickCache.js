// tickCache.js
// Redis-backed "last known tick" store. This is what makes the app
// never show blank: every tick, whether it arrived during market hours
// or was fetched on-demand after close, gets written here with NO TTL.
// It only gets overwritten by a newer tick -- never expires on its own.
//
// Redis key structure:
//   tick:{EXCHANGE}:{SYMBOL}  ->  JSON string:
//     { symbol, ltp, open, high, low, close, change, changePct,
//       volume, updatedAt }
//
// This is intentionally separate from any short-TTL "quote cache" used
// elsewhere for rate-limiting -- this key is the durable source of
// "last known state" for a symbol.
const redis = require('../config/redis');

const KEY_PREFIX = 'tick:';

async function setTick(symbol, tick) {
  try {
    await redis.set(KEY_PREFIX + symbol, JSON.stringify(tick));
  } catch { /* non-fatal -- worst case we just miss caching this one tick */ }
}

async function getTick(symbol) {
  try {
    const raw = await redis.get(KEY_PREFIX + symbol);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

async function getTicks(symbols) {
  const result = {};
  for (const sym of symbols) {
    const t = await getTick(sym);
    if (t) result[sym] = t;
  }
  return result;
}

module.exports = { setTick, getTick, getTicks };
