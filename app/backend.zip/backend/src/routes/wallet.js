// routes/wallet.js
const express  = require('express');
const auth     = require('../middleware/auth');
const db       = require('../config/database');
const { logger } = require('../config/logger');
const router   = express.Router();

// GET /api/v1/wallet — user's own balance + recent transactions
router.get('/', auth, async (req, res) => {
  const uid = req.user.userId;
  try {
    const [[wallet]]  = await db.pool.query(
      'SELECT COALESCE(balance, 0) as balance FROM app_wallet WHERE user_id=?', [uid]);
    const [txns]      = await db.pool.query(
      'SELECT * FROM wallet_transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 20', [uid]);
    res.json({ balance: wallet?.balance || 0, transactions: txns });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Admin: POST /api/v1/wallet/admin/adjust { userId, amount, type: 'credit'|'debit', note }
// (admin-only — checked by admin-specific JWT role in admin.js, called from admin panel)
router.post('/admin/adjust', async (req, res) => {
  const adminToken = req.headers.authorization?.split(' ')[1];
  if (!adminToken) return res.status(401).json({ error: 'Not authenticated' });
  const jwt = require('jsonwebtoken');
  try {
    const payload = jwt.verify(adminToken, process.env.JWT_SECRET);
    if (payload.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  } catch { return res.status(401).json({ error: 'Invalid token' }); }

  const { userId, amount, type, note } = req.body;
  if (!userId || !amount || !type) return res.status(400).json({ error: 'userId, amount, type required' });
  const amt = parseFloat(amount);
  if (isNaN(amt) || amt <= 0) return res.status(400).json({ error: 'Amount must be positive' });
  try {
    // Ensure wallet row exists
    await db.pool.query(
      'INSERT INTO app_wallet (user_id, balance) VALUES (?,0) ON DUPLICATE KEY UPDATE user_id=user_id',
      [userId]
    );
    const delta = type === 'credit' ? amt : -amt;
    await db.pool.query('UPDATE app_wallet SET balance = balance + ? WHERE user_id=?', [delta, userId]);
    await db.pool.query(
      'INSERT INTO wallet_transactions (user_id, type, amount, note, done_by) VALUES (?,?,?,?,?)',
      [userId, type, amt, note || (type === 'credit' ? 'Admin credit' : 'Admin debit'), 'admin']
    );
    const [[wallet]] = await db.pool.query('SELECT balance FROM app_wallet WHERE user_id=?', [userId]);
    res.json({ ok: true, newBalance: wallet.balance });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
