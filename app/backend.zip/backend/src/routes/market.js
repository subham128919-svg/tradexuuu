// routes/market.js -- PUBLIC endpoints (no auth), now market-status-aware.
const express          = require('express');
const kite               = require('../services/kiteService');
const marketDataService   = require('../services/marketDataService');
const candleStore          = require('../services/candleStore');
const { getMarketStatus }  = require('../services/marketStatusService');
const UNIVERSE               = require('../config/universe');
const { logger }             = require('../config/logger');
const router                  = express.Router();

let instrumentSvc;
try { instrumentSvc = require('../services/instrumentService'); } catch (e) { instrumentSvc = null; }

// GET /api/v1/market/status
// Lets the app show a clear "Market Closed -- showing last known
// prices" banner, or an "as of HH:MM" label, instead of guessing.
router.get('/status', (req, res) => {
  res.json(getMarketStatus());
});

// GET /api/v1/market/quotes?symbols=NSE:RELIANCE,NSE:TCS
// Now Redis-tick-cache-first via marketDataService. During market hours
// this stays live (<=3s old); after close it serves the last known
// tick indefinitely -- never blank, never an extra Kite call once a
// symbol has been seen once.
router.get('/quotes', async (req, res) => {
  const symbols = req.query.symbols?.split(',').map(s => s.trim());
  if (!symbols?.length) return res.status(400).json({ error: 'symbols required' });
  try {
    const { ticks, marketStatus } = await marketDataService.getQuotesSmart(symbols);
    const data = symbols
      .map(sym => ticks[sym] ? { ...ticks[sym], name: sym.split(':')[1] } : null)
      .filter(Boolean);
    res.json({ data, marketStatus });
  } catch (err) {
    logger.error('GET /quotes', err.message);
    res.status(500).json({ error: err.message });
  }
});

// GET /api/v1/market/candles?symbol=NSE:RELIANCE&period=1M
// DB-first. Works identically whether market is open or closed --
// history doesn't change based on session state.
router.get('/candles', async (req, res) => {
  const { symbol, period = '1M' } = req.query;
  if (!symbol) return res.status(400).json({ error: 'symbol required' });
  try {
    const data = await candleStore.getCandles(symbol, period);
    res.json({ data });
  } catch (err) {
    logger.error('GET /candles', err.message);
    res.status(500).json({ error: err.message });
  }
});

router.get('/search', async (req, res) => {
  const { q, exchange } = req.query;
  if (!q) return res.status(400).json({ error: 'q required' });
  try {
    if (instrumentSvc) {
      res.json({ data: await instrumentSvc.searchInstruments(q, exchange) });
    } else {
      res.json({ data: [{ symbol: q.toUpperCase(), name: q.toUpperCase(), exchange: exchange || 'NSE' }] });
    }
  } catch (err) {
    logger.error('GET /search', err.message);
    res.status(500).json({ error: err.message });
  }
});

// GET /api/v1/market/indices -- also routed through the smart cache.
router.get('/indices', async (req, res) => {
  const INDICES = ['NSE:NIFTY 50', 'BSE:SENSEX', 'NSE:NIFTY BANK', 'NSE:INDIA VIX'];
  try {
    const { ticks, marketStatus } = await marketDataService.getQuotesSmart(INDICES);
    const data = INDICES.map(sym => ticks[sym] ? {
      ...ticks[sym], name: sym.split(':')[1], isPositive: (ticks[sym].change || 0) >= 0
    } : null).filter(Boolean);
    res.json({ data, marketStatus });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/v1/market/explore?type=trending|gainers|losers
router.get('/explore', async (req, res) => {
  const { type = 'trending' } = req.query;
  try {
    const { ticks, marketStatus } = await marketDataService.getQuotesSmart(UNIVERSE);
    let list = Object.values(ticks).map(t => ({
      ...t, name: t.symbol.split(':')[1], isPositive: (t.change || 0) >= 0
    }));
    if (type === 'gainers')  list = list.filter(s => s.changePct > 0).sort((a, b) => b.changePct - a.changePct);
    if (type === 'losers')   list = list.filter(s => s.changePct < 0).sort((a, b) => a.changePct - b.changePct);
    if (type === 'trending') list = list.sort((a, b) => Math.abs(b.changePct) - Math.abs(a.changePct));
    res.json({ data: list.slice(0, 20), marketStatus });
  } catch (err) {
    logger.error('GET /explore', err.message);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
