// scheduler.js -- background jobs. Required and started from index.js.
//
// Job: post-close candle sync
//   At 15:35 IST (5 min after market close), Mon-Fri, pull the day's
//   final candles for every tracked instrument and persist to MySQL.
//   This means for the rest of the evening -- and the whole time the
//   market is closed the next morning until someone opens the app --
//   chart requests are served entirely from the DB with zero Kite
//   calls, which is both faster and doesn't burn API quota.
const cron          = require('node-cron');
const candleStore    = require('./services/candleStore');
const UNIVERSE        = require('./config/universe');
const { logger }      = require('./config/logger');

function startScheduler() {
  cron.schedule('35 15 * * 1-5', async () => {
    logger.info('Scheduler: post-close candle sync starting');
    for (const symbol of UNIVERSE) {
      try {
        await candleStore.getCandles(symbol, '1D');
        await candleStore.getCandles(symbol, '1M');
      } catch (err) {
        logger.error('Scheduler: candle sync failed for ' + symbol + ' -- ' + err.message);
      }
      await new Promise(r => setTimeout(r, 300)); // gentle pacing vs Kite rate limits
    }
    logger.info('Scheduler: post-close candle sync done');
  }, { timezone: 'Asia/Kolkata' });

  logger.info('Scheduler started -- daily candle sync at 15:35 IST, Mon-Fri');
}

module.exports = { startScheduler };
