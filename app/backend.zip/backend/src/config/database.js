// database.js  —  MySQL connection (using mysql2 which is faster than mysql)
// Your server already has MySQL from the LAMP setup — no extra install needed!
const mysql      = require('mysql2/promise');
const { logger } = require('./logger');

const pool = mysql.createPool({
  host:               process.env.DB_HOST     || 'localhost',
  port:               parseInt(process.env.DB_PORT || '3306'),
  user:               process.env.DB_USER     || 'tradingapp',
  password:           process.env.DB_PASSWORD || '',
  database:           process.env.DB_NAME     || 'tradingapp',
  waitForConnections: true,
  connectionLimit:    20,
  queueLimit:         0,
  timezone:           '+05:30',   // IST
});

// Test connection on startup
async function connect() {
  const conn = await pool.getConnection();
  await conn.query('SELECT 1');
  conn.release();
  logger.info('MySQL connected');
}

// Helper that returns rows like PostgreSQL's pool.query
async function query(sql, params) {
  const [rows] = await pool.execute(sql, params || []);
  return { rows, rowCount: rows.length };
}

module.exports = { query, connect, pool };
