// TradingApp Backend -- Entry point
require('dotenv').config();

const express     = require('express');
const http        = require('http');
const cors        = require('cors');
const helmet      = require('helmet');
const rateLimit   = require('express-rate-limit');
const { logger }  = require('./config/logger');
const db          = require('./config/database');
const redis       = require('./config/redis');
const PriceStream = require('./websocket/priceStream');
const { startScheduler } = require('./scheduler');

const app    = express();
const server = http.createServer(app);

app.set('trust proxy', 1);

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json());
app.use(rateLimit({ windowMs: 60_000, max: 300 }));

const API  = '/api/v1';
const auth = require('./middleware/auth');

// PUBLIC routes -- no login needed
app.use(`${API}/auth`,      require('./routes/auth'));
app.use(`${API}/market`,    require('./routes/market'));
app.use(`${API}/mf`,        require('./routes/mf'));

// PROTECTED routes -- owner's own portfolio only
app.use(`${API}/portfolio`, auth, require('./routes/portfolio'));
app.use(`${API}/orders`,    auth, require('./routes/orders'));
app.use(`${API}/watchlist`, auth, require('./routes/watchlist'));

app.get('/health', (_, res) => res.json({ status: 'ok', ts: Date.now() }));

new PriceStream(server);

const PORT = process.env.PORT || 3000;

async function start() {
  try {
    try {
      await redis.connect();
      logger.info('Redis connected');
    } catch (e) {
      logger.warn('Redis connection failed, using in-memory fallback:', e.message);
    }

    try {
      const token = await redis.get('kite:access_token');
      if (token) {
        require('./services/kiteService').setAccessToken(token);
        logger.info('Kite session restored from Redis -- token present');
      } else {
        logger.warn('No Kite token found. Owner must login at /api/v1/auth/kite-login');
      }
    } catch (e) {
      logger.warn('Kite token restore failed:', e.message);
    }

    await db.connect();
    logger.info('MySQL connected');

    startScheduler();

    server.listen(PORT, () => logger.info('Server listening on :' + PORT));
  } catch (err) {
    logger.error('Startup failed', err);
    process.exit(1);
  }
}

start();
