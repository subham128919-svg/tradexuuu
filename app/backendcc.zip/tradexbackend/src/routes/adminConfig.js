// routes/adminConfig.js — NEW. Items 8, 10, plus the item 3 settings.
//
// Lot sizes: the lot_size_overrides table and the read path in
// optionChainService.getEffectiveLotSize() both already existed, but
// nothing in the codebase ever WROTE to that table — so it was
// permanently empty and every lot size came from Kite. This is the
// missing write side. With no override set, the exchange value is used,
// which is the "if admin has not decided, behave like real" behaviour.

const express    = require('express');
const adminAuth  = require('../middleware/adminAuth');
const db         = require('../config/database');
const settings   = require('../utils/settings');
const razorpay   = require('../services/razorpayService');
const { logger } = require('../config/logger');

const router = express.Router();

// ═══ LOT SIZES ═══════════════════════════════════════════════════

router.get('/lot-sizes', adminAuth, async (req, res) => {
  try {
    const [rows] = await db.pool.query(`
      SELECT i.underlying,
             MIN(i.lot_size)          AS kite_lot_size,
             o.lot_size               AS override_lot_size,
             o.updated_at             AS override_updated_at,
             o.updated_by             AS override_updated_by,
             COUNT(DISTINCT i.expiry) AS expiries,
             MIN(i.expiry)            AS nearest_expiry
        FROM instruments i
        LEFT JOIN lot_size_overrides o ON o.underlying = i.underlying
       WHERE i.exchange = 'NFO' AND i.underlying IS NOT NULL AND i.expiry >= CURDATE()
       GROUP BY i.underlying, o.lot_size, o.updated_at, o.updated_by
       ORDER BY i.underlying ASC`);

    res.json({ data: rows.map(r => ({
      underlying: r.underlying,
      kiteLotSize: r.kite_lot_size,
      overrideLotSize: r.override_lot_size,
      effectiveLotSize: r.override_lot_size > 0 ? r.override_lot_size : r.kite_lot_size,
      source: r.override_lot_size > 0 ? 'admin' : 'exchange',
      expiries: r.expiries, nearestExpiry: r.nearest_expiry,
      updatedAt: r.override_updated_at, updatedBy: r.override_updated_by,
    })) });
  } catch (err) {
    logger.error('adminConfig GET /lot-sizes: ' + err.message);
    res.status(500).json({ error: err.message });
  }
});

router.put('/lot-sizes/:underlying', adminAuth, async (req, res) => {
  const underlying = String(req.params.underlying || '').toUpperCase().trim();
  const lotSize    = parseInt(req.body.lotSize, 10);
  if (!underlying) return res.status(400).json({ error: 'underlying required' });
  if (!Number.isInteger(lotSize) || lotSize < 1 || lotSize > 1_000_000) {
    return res.status(400).json({ error: 'lotSize must be a positive integer' });
  }
  try {
    // Refuse an override on something that is not a real F&O underlying
    // — a typo would create a dead row that silently never applies.
    const [[exists]] = await db.pool.query(
      "SELECT 1 AS ok FROM instruments WHERE underlying = ? AND exchange = 'NFO' LIMIT 1",
      [underlying]);
    if (!exists) return res.status(404).json({ error: 'No NFO instruments for ' + underlying });

    await db.pool.query(
      'INSERT INTO lot_size_overrides (underlying, lot_size, updated_by) VALUES (?,?,?) ' +
      'ON DUPLICATE KEY UPDATE lot_size = VALUES(lot_size), updated_by = VALUES(updated_by)',
      [underlying, lotSize, req.admin?.username || 'admin']);

    logger.info(`admin set lot size ${underlying} = ${lotSize}`);
    res.json({ ok: true, underlying, lotSize, source: 'admin' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/lot-sizes/:underlying', adminAuth, async (req, res) => {
  const underlying = String(req.params.underlying || '').toUpperCase().trim();
  try {
    await db.pool.query('DELETE FROM lot_size_overrides WHERE underlying = ?', [underlying]);
    res.json({ ok: true, underlying, source: 'exchange' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ═══ RAZORPAY KEYS ═══════════════════════════════════════════════

function mask(s) {
  if (!s) return '';
  if (s.length <= 8) return '••••••••';
  return s.slice(0, 4) + '•'.repeat(Math.max(4, s.length - 8)) + s.slice(-4);
}

// The secret is never returned in full — a secret visible in a browser
// tab anyone can screenshot is not worth the convenience.
router.get('/razorpay', adminAuth, async (req, res) => {
  try {
    const all = await settings.getAll(true);
    const dbKeyId  = (all.razorpay_key_id || '').trim();
    const dbSecret = (all.razorpay_key_secret || '').trim();
    const dbHook   = (all.razorpay_webhook_secret || '').trim();
    const envKeyId = (process.env.RAZORPAY_KEY_ID || '').trim();
    const effectiveKeyId = dbKeyId || envKeyId;

    res.json({
      keyId: dbKeyId,
      keySecretSet: !!dbSecret, keySecretMasked: mask(dbSecret),
      webhookSecretSet: !!dbHook, webhookSecretMasked: mask(dbHook),
      effectiveKeyId,
      effectiveSource: dbKeyId ? 'database' : (envKeyId ? 'env' : 'none'),
      envKeyId, envSecretSet: !!(process.env.RAZORPAY_KEY_SECRET || '').trim(),
      mode: effectiveKeyId.startsWith('rzp_live') ? 'LIVE'
          : effectiveKeyId.startsWith('rzp_test') ? 'TEST' : 'UNKNOWN',
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Blank or omitted fields are left unchanged, so the key id can be
// rotated without re-typing the secret.
router.put('/razorpay', adminAuth, async (req, res) => {
  const { keyId, keySecret, webhookSecret } = req.body || {};
  const patch = {};
  if (typeof keyId === 'string' && keyId.trim()) {
    const k = keyId.trim();
    if (!/^rzp_(test|live)_[A-Za-z0-9]+$/.test(k)) {
      return res.status(400).json({ error: 'Key ID must look like rzp_test_xxxx or rzp_live_xxxx' });
    }
    patch.razorpay_key_id = k;
  }
  if (typeof keySecret === 'string' && keySecret.trim())
    patch.razorpay_key_secret = keySecret.trim();
  if (typeof webhookSecret === 'string' && webhookSecret.trim())
    patch.razorpay_webhook_secret = webhookSecret.trim();

  if (!Object.keys(patch).length) return res.status(400).json({ error: 'Nothing to update' });

  try {
    await settings.setMany(patch);
    settings.invalidate();
    razorpay.invalidate();      // drop the client memoized on the old keys
    logger.info('admin updated Razorpay credentials: ' + Object.keys(patch).join(', '));
    res.json({ ok: true, updated: Object.keys(patch) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Proves the keys work before a real customer discovers they do not.
router.post('/razorpay/test', adminAuth, async (req, res) => {
  try {
    const order = await razorpay.createOrder(1, 'admin_keytest_' + Date.now());
    res.json({ ok: true, message: 'Keys are valid. Test order created, nobody charged.',
               orderId: order.id });
  } catch (err) {
    res.status(400).json({ ok: false,
      error: err?.error?.description || err.message || 'Razorpay rejected these credentials' });
  }
});

// ═══ TRADING & RISK (item 3 / item 7 settings) ═══════════════════

const TRADING_KEYS = {
  equity_intraday_leverage: { label: 'Equity intraday leverage', min: 1,  max: 10 },
  equity_mtf_leverage:      { label: 'Equity MTF leverage',      min: 1,  max: 10 },
  fno_buy_leverage:         { label: 'F&O buy leverage',         min: 1,  max: 1  },
  fno_short_margin_pct:     { label: 'F&O short margin %',       min: 1,  max: 100 },
  mtf_interest_annual_pct:  { label: 'MTF interest % p.a.',      min: 0,  max: 36 },
};

router.get('/trading', adminAuth, async (req, res) => {
  try {
    const all = await settings.getAll(true);
    const out = {};
    for (const k of Object.keys(TRADING_KEYS)) out[k] = all[k] ?? '';
    out.intraday_squareoff_time = all.intraday_squareoff_time || '15:15';
    out.expiry_settlement_mode  = all.expiry_settlement_mode  || 'CASH';
    res.json({ data: out, meta: TRADING_KEYS });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.put('/trading', adminAuth, async (req, res) => {
  const patch = {};
  try {
    for (const [k, rule] of Object.entries(TRADING_KEYS)) {
      if (req.body[k] === undefined || req.body[k] === '') continue;
      const v = parseFloat(req.body[k]);
      if (!Number.isFinite(v) || v < rule.min || v > rule.max) {
        return res.status(400).json({
          error: `${rule.label} must be between ${rule.min} and ${rule.max}` });
      }
      patch[k] = String(v);
    }
    if (req.body.intraday_squareoff_time) {
      const t = String(req.body.intraday_squareoff_time).trim();
      if (!/^([01]\d|2[0-3]):([0-5]\d)$/.test(t)) {
        return res.status(400).json({ error: 'Square-off time must be HH:MM in 24-hour form' });
      }
      patch.intraday_squareoff_time = t;
    }
    if (req.body.expiry_settlement_mode) {
      const m = String(req.body.expiry_settlement_mode).toUpperCase();
      if (!['CASH', 'PHYSICAL'].includes(m)) {
        return res.status(400).json({ error: 'Settlement mode must be CASH or PHYSICAL' });
      }
      patch.expiry_settlement_mode = m;
    }
    if (!Object.keys(patch).length) return res.status(400).json({ error: 'Nothing to update' });

    await settings.setMany(patch);
    settings.invalidate();
    logger.info('admin updated trading settings: ' + Object.keys(patch).join(', '));
    res.json({ ok: true, updated: Object.keys(patch) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Manual triggers, so you can test the jobs without waiting for 15:15.
router.post('/run-squareoff', adminAuth, async (req, res) => {
  try {
    const r = await require('../services/settlementService').runIntradaySquareOff();
    res.json({ ok: true, ...r });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/run-expiry', adminAuth, async (req, res) => {
  try {
    const r = await require('../services/settlementService').runExpirySettlement(req.body?.date);
    res.json({ ok: true, ...r });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Recent automated exits, failures included — item 7 requires that a
// failed exit stays visible rather than being recorded as completed.
router.get('/settlements', adminAuth, async (req, res) => {
  try {
    const days = Math.min(90, Math.max(1, parseInt(req.query.days, 10) || 7));
    const [rows] = await db.pool.query(
      'SELECT s.*, u.name AS user_name, u.email FROM app_settlements s ' +
      'LEFT JOIN app_users u ON u.id = s.user_id ' +
      'WHERE s.run_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY) ' +
      'ORDER BY s.created_at DESC LIMIT 500', [days]);
    const [[fails]] = await db.pool.query(
      "SELECT COUNT(*) AS c FROM app_settlements WHERE result='FAILED' " +
      'AND run_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)', [days]);
    res.json({ data: rows, failedCount: fails.c });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
