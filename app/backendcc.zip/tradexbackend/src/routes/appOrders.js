// routes/appOrders.js — REPLACE. Items 3, 4, 5.
//
// Order placement now does three things the old version did not:
//   1. Blocks MARGIN, not full value. product was stored and ignored, so
//      DELIVERY, INTRADAY and MTF all debited 100% — no leverage existed.
//      marginService decides: 4x equity intraday and MTF, 1x delivery,
//      1x on F&O buys (full premium), margin% on F&O shorts.
//   2. Fills through the depth matcher, never at an invented price.
//   3. Routes the fill into app_positions, so Equity and F&O stay
//      separate and square-off/expiry have something to act on.
//
// Requires migrations 001 and 002.

const express             = require('express');
const auth                = require('../middleware/auth');
const db                  = require('../config/database');
const { getMarketStatus } = require('../services/marketStatusService');
const exec                = require('../services/executionService');
const marginService       = require('../services/marginService');
const positionService     = require('../services/positionService');
const tracker             = require('../services/backgroundTracker');
const { logger }          = require('../config/logger');
const router              = express.Router();

// POST /api/v1/app-orders
router.post('/', auth, async (req, res) => {
  const { symbol, exchange, name, orderType, product, priceType, qty, price } = req.body;
  if (!symbol || !orderType || !qty)
    return res.status(400).json({ error: 'symbol, orderType, qty required' });

  const side = String(orderType).toUpperCase();
  if (!['BUY', 'SELL'].includes(side))
    return res.status(400).json({ error: 'orderType must be BUY or SELL' });

  const status = getMarketStatus();
  if (!status.isOpen) {
    return res.status(400).json({
      error: 'Market is currently closed (' + status.session + '). Orders can only be placed ' +
             'during market hours (09:15-15:30 IST, Mon-Fri).' });
  }

  const uid = req.user.userId;
  const q   = Number(qty);
  if (!Number.isInteger(q) || q <= 0)
    return res.status(400).json({ error: 'Quantity must be a positive integer' });

  const ex       = (exchange || 'NSE').toUpperCase();
  const pType    = (priceType || 'MARKET').toUpperCase();
  const segment  = exec.segmentFor(ex);
  const prod     = marginService.normalizeProduct(product, segment);

  const productErr = marginService.validateProduct({ segment, product: prod, side });
  if (productErr) return res.status(400).json({ error: productErr });

  // ── F&O lot size (honours the admin override) ─────────────────
  if (segment === 'FNO') {
    try {
      const ocs = require('../services/optionChainService');
      const lot = await ocs.getLotSizeForSymbol(symbol.includes(':') ? symbol.split(':')[1] : symbol);
      if (lot && q % lot !== 0) {
        return res.status(400).json({
          error: `Quantity must be a multiple of the lot size (${lot}) for ${symbol}` });
      }
    } catch {}
  }

  // ── Live book before any money moves ──────────────────────────
  const book = await exec.getBook(symbol, ex);
  if (!book) {
    return res.status(400).json({
      error: 'No live market data for ' + symbol + ' right now. Try again in a moment.' });
  }

  let limitPrice = null;
  if (pType === 'LIMIT' || pType === 'SL') {
    limitPrice = Number(price);
    if (!Number.isFinite(limitPrice) || limitPrice <= 0)
      return res.status(400).json({ error: 'A valid limit price is required' });
    if (book.upperCircuit > 0 && limitPrice > book.upperCircuit)
      return res.status(400).json({
        error: `Limit Rs.${limitPrice.toFixed(2)} is above the upper circuit ` +
               `(Rs.${book.upperCircuit.toFixed(2)}) for ${symbol}` });
    if (book.lowerCircuit > 0 && limitPrice < book.lowerCircuit)
      return res.status(400).json({
        error: `Limit Rs.${limitPrice.toFixed(2)} is below the lower circuit ` +
               `(Rs.${book.lowerCircuit.toFixed(2)}) for ${symbol}` });
  }

  // Worst price we could pay/receive, used for the margin calculation.
  const worstPrice = limitPrice != null
    ? limitPrice
    : (side === 'BUY' ? (book.sell[0]?.price || book.ltp) * 1.02
                      : (book.buy[0]?.price  || book.ltp));

  const conn = await db.pool.getConnection();
  let orderId = null, marginInfo = null;
  try {
    await conn.beginTransaction();

    await conn.query(
      'INSERT INTO app_wallet (user_id, balance) VALUES (?,0) ON DUPLICATE KEY UPDATE user_id=user_id',
      [uid]);
    const [[wallet]] = await conn.query(
      'SELECT balance FROM app_wallet WHERE user_id=? FOR UPDATE', [uid]);
    const avail = parseFloat(wallet?.balance || 0);

    // Does this trade open exposure or close it? A SELL that closes an
    // existing long needs no margin; a SELL with nothing to close is a
    // short and does.
    const existing = await openPositionFor(conn, uid, symbol, prod);
    const openQty  = existing ? existing.qty : 0;
    const isOpening = side === 'BUY' ? openQty >= 0 : openQty <= 0;

    // Equity DELIVERY/MTF sells must be covered by settled holdings or
    // an open long — you cannot deliver shares you do not have.
    if (side === 'SELL' && segment === 'EQUITY' && prod !== 'INTRADAY') {
      const cover = await sellableQty(conn, uid, symbol, prod);
      if (q > cover) {
        await conn.rollback(); conn.release();
        return res.status(400).json({
          error: `Insufficient quantity. You can sell ${cover} of ${symbol} ` +
                 `(holdings plus today's position, minus open sell orders).` });
      }
    }

    marginInfo = await marginService.requiredMargin({
      side, segment, product: prod, qty: q, price: worstPrice, isOpening,
    });
    if (marginInfo.blocked) {
      await conn.rollback(); conn.release();
      return res.status(400).json({ error: marginInfo.basis });
    }

    if (marginInfo.amount > 0) {
      if (avail < marginInfo.amount) {
        await conn.rollback(); conn.release();
        return res.status(400).json({
          error: `Insufficient margin. Available: Rs.${avail.toFixed(2)}, ` +
                 `required: Rs.${marginInfo.amount.toFixed(2)} ` +
                 `(${marginInfo.basis}, notional Rs.${marginInfo.notional.toFixed(2)})` });
      }
      await conn.query('UPDATE app_wallet SET balance = balance - ? WHERE user_id=?',
        [marginInfo.amount, uid]);
      await conn.query(
        'INSERT INTO wallet_transactions (user_id, type, amount, note, done_by) VALUES (?,?,?,?,?)',
        [uid, 'debit', marginInfo.amount,
         `Margin blocked: ${side} ${q} ${symbol} ${prod} (${marginInfo.leverage}x)`, 'system']);
    }

    const [ins] = await conn.query(
      'INSERT INTO app_orders (user_id, symbol, exchange, segment, name, order_type, product, ' +
      ' price_type, qty, filled_qty, price, avg_price, blocked_amount, status) ' +
      "VALUES (?,?,?,?,?,?,?,?,?,0,?,NULL,?,'PENDING')",
      [uid, symbol, ex, segment, name || symbol, side, prod, pType, q,
       worstPrice, marginInfo.amount]);
    orderId = ins.insertId;

    await conn.commit(); conn.release();
  } catch (err) {
    try { await conn.rollback(); } catch {}
    conn.release();
    logger.error('appOrders POST: ' + err.message);
    return res.status(500).json({ error: err.message });
  }

  // ── Try to fill immediately against the book ──────────────────
  try {
    const [[fresh]] = await db.pool.query('SELECT * FROM app_orders WHERE id=?', [orderId]);
    await exec.attemptFill(fresh);
  } catch (e) {
    logger.warn(`immediate fill attempt for order ${orderId}: ${e.message}`);
  }

  tracker.addSymbol(exec.fullSymbol(symbol, ex), side.toLowerCase()).catch(() => {});

  try {
    const [[o]]    = await db.pool.query('SELECT * FROM app_orders WHERE id=?', [orderId]);
    const [[bal]]  = await db.pool.query('SELECT balance FROM app_wallet WHERE user_id=?', [uid]);
    const [trades] = await db.pool.query(
      'SELECT qty, price, depth_level FROM app_trades WHERE order_id=? ORDER BY id ASC', [orderId]);

    const filled = o.filled_qty, avg = parseFloat(o.avg_price || 0);
    let message;
    if (o.status === 'EXECUTED') {
      message = `${side} ${filled} filled @ avg Rs.${avg.toFixed(2)}`;
    } else if (o.status === 'PARTIAL') {
      message = `${side} partially filled: ${filled} of ${o.qty} @ avg Rs.${avg.toFixed(2)}. ` +
                `${o.qty - filled} still open at Rs.${parseFloat(o.price).toFixed(2)}.`;
    } else {
      const best = side === 'BUY' ? book.sell[0]?.price : book.buy[0]?.price;
      message = `Order placed and open. Nothing available at Rs.${parseFloat(o.price).toFixed(2)} yet` +
                (best ? ` (best ${side === 'BUY' ? 'offer' : 'bid'} Rs.${best.toFixed(2)})` : '') + '.';
    }

    res.json({
      success: true, orderId, status: o.status, message,
      product: prod, segment,
      qty: o.qty, filledQty: filled, pendingQty: o.qty - filled,
      avgPrice: avg, executedPrice: avg,
      margin: {
        blocked: marginInfo.amount, leverage: marginInfo.leverage,
        notional: marginInfo.notional, basis: marginInfo.basis,
      },
      trades: trades.map(t => ({ qty: t.qty, price: parseFloat(t.price), level: t.depth_level })),
      newBalance: bal?.balance || 0,
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

async function openPositionFor(conn, uid, symbol, product) {
  const [rows] = await conn.query(
    "SELECT * FROM app_positions WHERE user_id=? AND symbol=? AND product=? AND status='OPEN' LIMIT 1",
    [uid, symbol, product]);
  return rows[0] || null;
}

// Settled holdings + any open long today, minus quantity already
// committed to other open sell orders.
async function sellableQty(conn, uid, symbol, product) {
  const [[h]] = await conn.query(
    'SELECT COALESCE(SUM(qty),0) AS q FROM app_holdings WHERE user_id=? AND symbol=?',
    [uid, symbol]);
  const [[p]] = await conn.query(
    "SELECT COALESCE(SUM(GREATEST(qty,0)),0) AS q FROM app_positions " +
    "WHERE user_id=? AND symbol=? AND product=? AND status='OPEN'",
    [uid, symbol, product]);
  const [[pend]] = await conn.query(
    "SELECT COALESCE(SUM(qty - filled_qty),0) AS q FROM app_orders " +
    "WHERE user_id=? AND symbol=? AND order_type='SELL' AND status IN ('PENDING','PARTIAL')",
    [uid, symbol]);
  return Number(h.q) + Number(p.q) - Number(pend.q);
}

// POST /api/v1/app-orders/:id/cancel
router.post('/:id/cancel', auth, async (req, res) => {
  const uid = req.user.userId, id = parseInt(req.params.id, 10);
  const conn = await db.pool.getConnection();
  try {
    await conn.beginTransaction();
    const [[o]] = await conn.query(
      'SELECT * FROM app_orders WHERE id=? AND user_id=? FOR UPDATE', [id, uid]);
    if (!o) { await conn.rollback(); conn.release(); return res.status(404).json({ error: 'Order not found' }); }
    if (!['PENDING', 'PARTIAL'].includes(o.status)) {
      await conn.rollback(); conn.release();
      return res.status(400).json({ error: `Order is ${o.status} and cannot be cancelled` });
    }
    const refund = parseFloat(o.blocked_amount || 0);
    if (refund > 0.0001) {
      await conn.query('UPDATE app_wallet SET balance = balance + ? WHERE user_id=?', [refund, uid]);
      await conn.query(
        'INSERT INTO wallet_transactions (user_id, type, amount, note, done_by) VALUES (?,?,?,?,?)',
        [uid, 'credit', refund, `Margin released on cancelling order #${id}`, 'system']);
    }
    await conn.query("UPDATE app_orders SET status='CANCELLED', blocked_amount=0 WHERE id=?", [id]);
    await conn.commit(); conn.release();
    res.json({ ok: true, cancelled: id, refunded: refund, filledQty: o.filled_qty });
  } catch (e) {
    try { await conn.rollback(); } catch {}
    conn.release();
    res.status(500).json({ error: e.message });
  }
});

// GET /api/v1/app-orders/book?symbol=RELIANCE&exchange=NSE
// Live 5-level depth, so the order screen can show what is actually
// available before the user picks a limit price.
router.get('/book', auth, async (req, res) => {
  const { symbol, exchange } = req.query;
  if (!symbol) return res.status(400).json({ error: 'symbol required' });
  try {
    const book = await exec.getBook(symbol, exchange || 'NSE');
    if (!book) return res.json({ available: false, buy: [], sell: [] });
    res.json({ available: true, symbol: book.symbol, ltp: book.ltp,
      buy: book.buy, sell: book.sell,
      upperCircuit: book.upperCircuit, lowerCircuit: book.lowerCircuit, ageMs: book.age });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/v1/app-orders/margin?symbol=&exchange=&product=&qty=&price=&side=
// Preview the margin before placing, so the order screen can show
// "4x - Rs.X required" instead of the user discovering it on rejection.
router.get('/margin', auth, async (req, res) => {
  try {
    const ex      = (req.query.exchange || 'NSE').toUpperCase();
    const segment = exec.segmentFor(ex);
    const prod    = marginService.normalizeProduct(req.query.product, segment);
    const qty     = Number(req.query.qty) || 0;
    const side    = (req.query.side || 'BUY').toUpperCase();
    let price     = Number(req.query.price) || 0;

    if (!price) {
      const book = await exec.getBook(req.query.symbol, ex);
      price = side === 'BUY' ? (book?.sell[0]?.price || book?.ltp || 0)
                             : (book?.buy[0]?.price  || book?.ltp || 0);
    }
    const [[bal]] = await db.pool.query(
      'SELECT balance FROM app_wallet WHERE user_id=?', [req.user.userId]);
    const balance = parseFloat(bal?.balance || 0);

    const m  = await marginService.requiredMargin({
      side, segment, product: prod, qty, price, isOpening: true });
    const bp = await marginService.buyingPower(balance, { segment, product: prod });

    res.json({
      product: prod, segment, price,
      required: m.amount, leverage: m.leverage, notional: m.notional, basis: m.basis,
      balance, buyingPower: bp.buyingPower,
      maxQty: price > 0 && m.leverage > 0
        ? Math.floor((balance * m.leverage) / price) : 0,
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/v1/app-orders?status=PENDING&segment=FNO
router.get('/', auth, async (req, res) => {
  try {
    const { status, segment } = req.query;
    const params = [req.user.userId];
    let sql = 'SELECT * FROM app_orders WHERE user_id=?';
    if (status)  { sql += ' AND status=?';  params.push(String(status).toUpperCase()); }
    if (segment) { sql += ' AND segment=?'; params.push(String(segment).toUpperCase()); }
    sql += ' ORDER BY placed_at DESC';
    const [rows] = await db.pool.query(sql, params);
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/v1/app-orders/:id/trades — the individual fills
router.get('/:id/trades', auth, async (req, res) => {
  try {
    const [rows] = await db.pool.query(
      'SELECT * FROM app_trades WHERE order_id=? AND user_id=? ORDER BY id ASC',
      [req.params.id, req.user.userId]);
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/v1/app-orders/positions
// Kept for backward compatibility with the current app build. New
// screens should use /api/v1/app-portfolio/positions, which separates
// Equity from F&O. This proxies to it and returns the combined list.
router.get('/positions', auth, async (req, res) => {
  try {
    const portfolio = require('../services/portfolioView');
    const out = await portfolio.positions(req.user.userId, null);
    res.json({
      data: out.positions,
      totalValue: out.totals.currentValue,
      totalInvested: out.totals.invested,
      totalPnl: out.totals.totalPnl,
      totalPnlPct: out.totals.totalPnlPct,
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
