// routes/_patchRoutes.js
//
// Mounts every route added by these patches, so index.js needs exactly
// one line:   require('./routes/_patchRoutes')(app);
//
// /api/v1/admin is mounted several times on purpose: Express tries
// routes/admin.js first and falls through to adminExtra.js and
// adminConfig.js only for paths it does not handle, so nothing is
// shadowed. app-portfolio is a new path, so it cannot collide with the
// existing /portfolio router.
module.exports = function mountPatchRoutes(app) {
  const API = '/api/v1';

  app.use(`${API}/settings`,       require('./settings'));
  app.use(`${API}/referrals`,      require('./referrals'));
  app.use(`${API}/withdrawals`,    require('./withdrawals'));
  app.use(`${API}/app-orders-ex`,  require('./appOrdersExtra'));
  app.use(`${API}/app-portfolio`,  require('./appPortfolio'));   // NEW
  app.use(`${API}/admin`,          require('./adminExtra'));
  app.use(`${API}/admin`,          require('./adminConfig'));    // NEW

  console.log('[patch] settings, referrals, withdrawals, app-orders-ex, ' +
              'app-portfolio, admin-extra, admin-config mounted');
};
