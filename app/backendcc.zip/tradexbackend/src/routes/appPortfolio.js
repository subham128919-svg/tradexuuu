// routes/appPortfolio.js — NEW. Item 5.
//
// Mounted at /api/v1/app-portfolio. The existing /api/v1/portfolio
// router is left untouched so nothing in the current app build breaks.
const express         = require('express');
const auth            = require('../middleware/auth');
const db              = require('../config/database');
const portfolioView   = require('../services/portfolioView');
const positionService = require('../services/positionService');
const router          = express.Router();

function seg(v) {
  const s = String(v || '').toUpperCase();
  return (s === 'EQUITY' || s === 'FNO') ? s : null;
}

// GET /api/v1/app-portfolio/positions?segment=EQUITY|FNO
// Same-day trades and every open F&O position. Overnight F&O stays
// here rather than migrating to holdings, as specified.
router.get('/positions', auth, async (req, res) => {
  try {
    const out = await portfolioView.positions(req.user.userId, seg(req.query.segment));
    res.json({ data: out.positions, totals: out.totals });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/v1/app-portfolio/holdings
// Settled delivery and MTF equity only.
router.get('/holdings', auth, async (req, res) => {
  try {
    const out = await portfolioView.holdings(req.user.userId);
    res.json({ data: out.holdings, totals: out.totals });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/v1/app-portfolio/summary
// One call for the dashboard: both segments plus holdings.
router.get('/summary', auth, async (req, res) => {
  try {
    const uid = req.user.userId;
    const [equity, fno, held, [[bal]]] = await Promise.all([
      portfolioView.positions(uid, 'EQUITY'),
      portfolioView.positions(uid, 'FNO'),
      portfolioView.holdings(uid),
      db.pool.query('SELECT balance FROM app_wallet WHERE user_id=?', [uid]),
    ]);
    res.json({
      balance: parseFloat(bal?.balance || 0),
      equity: { count: equity.positions.length, totals: equity.totals },
      fno:    { count: fno.positions.length,    totals: fno.totals },
      holdings: { count: held.holdings.length,  totals: held.totals },
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/v1/app-portfolio/settlements?days=7
// Square-off and expiry history, successes and failures alike. A
// failed exit stays visible here instead of being silently dropped.
router.get('/settlements', auth, async (req, res) => {
  try {
    const days = Math.min(90, Math.max(1, parseInt(req.query.days, 10) || 7));
    const [rows] = await db.pool.query(
      'SELECT * FROM app_settlements WHERE user_id=? AND run_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY) ' +
      'ORDER BY created_at DESC', [req.user.userId, days]);
    res.json({ data: rows });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
