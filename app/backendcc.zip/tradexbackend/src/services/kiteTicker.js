// kiteTicker.js — NEW. Live KiteTicker websocket feed.
//
// There was no KiteTicker anywhere in this backend: every price came
// from REST polling. Kite rate-limits /quote to ~1 req/sec and caps it
// at 500 instruments, so a full option chain could neither load nor
// update. One websocket carries 3000 instruments with no rate limit,
// and in full mode it also streams OI and 5-level depth — which the
// order matcher needs. See README "Item 2".
//
// Writes into the same tickCache everything else already reads.
const { KiteTicker } = require('kiteconnect');
const EventEmitter   = require('events');
const db             = require('../config/database');
const redis          = require('../config/redis');
const tickCache      = require('./tickCache');
const { logger }     = require('../config/logger');

const MAX_TOKENS        = 2800;   // Kite allows 3000; keep headroom
const FULL_MODE_LIMIT   = 1000;   // depth+OI for the most recently used
const RESUB_DEBOUNCE_MS = 400;

class TickerService extends EventEmitter {
  constructor() {
    super();
    this.ticker = null;
    this.connected = false;
    this.tokens = new Map();        // token -> { symbol, refs, lastUsed, full }
    this.symbolToken = new Map();
    this.tokenSymbol = new Map();
    this._resubTimer = null;
    this._starting = false;
  }

  async start() {
    if (this.ticker || this._starting) return;
    this._starting = true;
    try {
      const apiKey = process.env.KITE_API_KEY;
      const accessToken = await redis.get('kite:access_token');
      if (!apiKey || !accessToken) {
        logger.warn('kiteTicker: no API key / access token yet — idle until next Kite login');
        return;
      }
      this.ticker = new KiteTicker({ api_key: apiKey, access_token: accessToken });
      this.ticker.on('connect', () => {
        this.connected = true;
        logger.info('kiteTicker: connected');
        this._applySubscriptions();
      });
      this.ticker.on('ticks', (t) => this._onTicks(t));
      this.ticker.on('disconnect', () => {
        this.connected = false;
        logger.warn('kiteTicker: disconnected (will auto-reconnect)');
      });
      this.ticker.on('noreconnect', () => {
        this.connected = false;
        logger.error('kiteTicker: gave up reconnecting — falling back to REST polling');
      });
      this.ticker.on('error', (e) => logger.warn('kiteTicker error: ' + (e?.message || e)));
      this.ticker.autoReconnect(true, -1, 5);
      this.ticker.connect();
    } catch (e) {
      logger.error('kiteTicker start failed: ' + e.message);
    } finally {
      this._starting = false;
    }
  }

  // Called by auth.js after a fresh Kite login, so the ticker picks up
  // the new access token without a server restart.
  async restart() {
    try { this.ticker?.disconnect(); } catch {}
    this.ticker = null; this.connected = false;
    await this.start();
  }

  isLive() { return this.connected; }

  // 'NFO:NIFTY25O0725000CE' -> instrument_token, from the local
  // instruments table. No Kite call, no 100MB CSV download.
  async resolveTokens(fullSymbols) {
    const out = new Map(), unknown = [];
    for (const fs of fullSymbols) {
      const c = this.symbolToken.get(fs);
      if (c) out.set(fs, c); else unknown.push(fs);
    }
    if (!unknown.length) return out;

    const byExchange = new Map();
    for (const fs of unknown) {
      const i = fs.indexOf(':');
      const ex = i === -1 ? 'NSE' : fs.slice(0, i);
      const sym = i === -1 ? fs : fs.slice(i + 1);
      if (!byExchange.has(ex)) byExchange.set(ex, []);
      byExchange.get(ex).push(sym);
    }
    for (const [ex, symbols] of byExchange) {
      try {
        const [rows] = await db.pool.query(
          'SELECT instrument_token, tradingsymbol FROM instruments WHERE exchange = ? AND tradingsymbol IN (?)',
          [ex, symbols]);
        for (const r of rows) {
          const fs = ex + ':' + r.tradingsymbol, token = Number(r.instrument_token);
          this.symbolToken.set(fs, token);
          this.tokenSymbol.set(token, fs);
          out.set(fs, token);
        }
      } catch (e) {
        logger.warn('kiteTicker.resolveTokens(' + ex + '): ' + e.message);
      }
    }
    return out;
  }

  // Reference counted, so the chain screen and the watchlist can both
  // hold NIFTY without either unsubscribe killing the other's feed.
  async subscribe(fullSymbols, { full = false } = {}) {
    if (!fullSymbols?.length) return;
    const resolved = await this.resolveTokens(fullSymbols);
    const now = Date.now();
    for (const [fs, token] of resolved) {
      const e = this.tokens.get(token);
      if (e) { e.refs++; e.lastUsed = now; if (full) e.full = true; }
      else this.tokens.set(token, { symbol: fs, refs: 1, lastUsed: now, full });
    }
    this._evictIfNeeded();
    this._scheduleResub();
  }

  async unsubscribe(fullSymbols) {
    if (!fullSymbols?.length) return;
    const resolved = await this.resolveTokens(fullSymbols);
    for (const [, token] of resolved) {
      const e = this.tokens.get(token);
      if (!e) continue;
      if (--e.refs <= 0) this.tokens.delete(token);
    }
    this._scheduleResub();
  }

  _evictIfNeeded() {
    if (this.tokens.size <= MAX_TOKENS) return;
    const sorted = [...this.tokens.entries()].sort((a, b) => a[1].lastUsed - b[1].lastUsed);
    let excess = this.tokens.size - MAX_TOKENS;
    for (const [token, e] of sorted) {
      if (excess <= 0) break;
      if (e.refs > 0) continue;
      this.tokens.delete(token); excess--;
    }
  }

  _scheduleResub() {
    clearTimeout(this._resubTimer);
    this._resubTimer = setTimeout(() => this._applySubscriptions(), RESUB_DEBOUNCE_MS);
  }

  _applySubscriptions() {
    if (!this.connected || !this.ticker) return;
    const all = [...this.tokens.keys()];
    if (!all.length) return;
    try {
      this.ticker.subscribe(all);
      // Full mode carries OI + depth but is bandwidth heavy, so reserve
      // it for the instruments actually on screen. Quote mode still has
      // LTP, OHLC and volume, which is all an accurate change% needs.
      const ranked = [...this.tokens.entries()].sort((a, b) => b[1].lastUsed - a[1].lastUsed);
      const fullTokens  = ranked.slice(0, FULL_MODE_LIMIT).map(e => e[0]);
      const quoteTokens = ranked.slice(FULL_MODE_LIMIT).map(e => e[0]);
      if (fullTokens.length)  this.ticker.setMode(this.ticker.modeFull,  fullTokens);
      if (quoteTokens.length) this.ticker.setMode(this.ticker.modeQuote, quoteTokens);
    } catch (e) {
      logger.warn('kiteTicker.subscribe failed: ' + e.message);
    }
  }

  _onTicks(ticks) {
    const now = Date.now();
    for (const t of ticks) {
      const symbol = this.tokenSymbol.get(Number(t.instrument_token));
      if (!symbol) continue;
      const close = Number(t.ohlc?.close) || 0;
      const ltp   = Number(t.last_price)  || 0;
      // Derive change when Kite omits it (common on illiquid strikes),
      // and report 0 rather than dividing by a fabricated base when
      // there is no previous close. See README "Item 2".
      const change = Number.isFinite(t.change) && t.change !== 0
        ? Number(t.change) : (close > 0 ? ltp - close : 0);
      const changePct = close > 0 ? parseFloat(((ltp - close) / close * 100).toFixed(2)) : 0;
      const depth = t.depth || null;
      const tick = {
        symbol, ltp,
        open:  Number(t.ohlc?.open) || 0,
        high:  Number(t.ohlc?.high) || 0,
        low:   Number(t.ohlc?.low)  || 0,
        close,
        change: parseFloat(Number(change).toFixed(2)),
        changePct,
        changeAvailable: close > 0 && ltp > 0,
        volume: Number(t.volume_traded ?? t.volume) || 0,
        oi: Number(t.oi) || 0,
        avgPrice: Number(t.average_traded_price) || 0,
        bid: Number(depth?.buy?.[0]?.price) || 0,
        ask: Number(depth?.sell?.[0]?.price) || 0,
        bidQty: Number(depth?.buy?.[0]?.quantity) || 0,
        askQty: Number(depth?.sell?.[0]?.quantity) || 0,
        depth: depth ? { buy: depth.buy || [], sell: depth.sell || [] } : null,
        updatedAt: now,
      };
      tickCache.setTick(symbol, tick).catch(() => {});
      const e = this.tokens.get(Number(t.instrument_token));
      if (e) e.lastUsed = now;
      this.emit('tick', tick);
    }
  }
}

module.exports = new TickerService();
