// positionService.js — NEW. Items 5 and 7.
//
// Every fill now lands in app_positions, not straight into app_holdings.
// That is what makes Equity and F&O separable, lets an F&O position be
// carried overnight, and gives intraday square-off and expiry settlement
// something concrete to act on.
//
// Lifecycle:
//   fill  -> applyFill()  opens / adds / reduces / flips a position
//   15:15 -> settlementService squares off INTRADAY positions
//   T+1   -> settleDelivery() moves settled DELIVERY qty into holdings
//   expiry-> settlementService cash-settles F&O positions
//
// Signed quantity throughout: positive is long, negative is short.
// app_holdings cannot express a short, which is why positions exist.

const db         = require('../config/database');
const { logger } = require('../config/logger');

function istDateString(d = new Date()) {
  const ist = new Date(d.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
  return ist.getFullYear() + '-' +
         String(ist.getMonth() + 1).padStart(2, '0') + '-' +
         String(ist.getDate()).padStart(2, '0');
}

// Next trading day, skipping the weekend. Exchange holidays are not
// modelled here; a holiday just means settlement lands a day early,
// which is harmless for display purposes.
function nextSettlementDate(from = new Date()) {
  const d = new Date(from.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
  d.setDate(d.getDate() + 1);
  while (d.getDay() === 0 || d.getDay() === 6) d.setDate(d.getDate() + 1);
  return istDateString(d);
}

/**
 * Apply one fill to the user's position book. Runs inside the caller's
 * transaction so a fill and its position update commit together.
 *
 * Returns { realisedPnl, closedQty, openedQty, position }.
 */
async function applyFill(conn, {
  userId, symbol, exchange, segment, product, name,
  side, qty, price, marginPerUnit = 0, meta = {},
}) {
  const tradeDate = istDateString();
  const signed    = side === 'BUY' ? qty : -qty;

  // An INTRADAY position is scoped to its trade date so yesterday's
  // (already squared off) row can never be reopened by today's fill.
  // DELIVERY and MTF carry forward, so they match on any open row.
  const [rows] = await conn.query(
    product === 'INTRADAY'
      ? "SELECT * FROM app_positions WHERE user_id=? AND symbol=? AND product=? " +
        "AND trade_date=? AND status='OPEN' FOR UPDATE"
      : "SELECT * FROM app_positions WHERE user_id=? AND symbol=? AND product=? " +
        "AND status='OPEN' FOR UPDATE",
    product === 'INTRADAY'
      ? [userId, symbol, product, tradeDate]
      : [userId, symbol, product]
  );
  const pos = rows[0] || null;

  let realisedPnl = 0, closedQty = 0, openedQty = 0;

  if (!pos) {
    const [ins] = await conn.query(
      'INSERT INTO app_positions (user_id, symbol, exchange, segment, product, name, ' +
      ' qty, avg_price, realised_pnl, margin_blocked, expiry, lot_size, instrument_type, ' +
      ' strike, status, trade_date) ' +
      "VALUES (?,?,?,?,?,?,?,?,0,?,?,?,?,?,'OPEN',?)",
      [userId, symbol, (exchange || 'NSE').toUpperCase(), segment, product, name || symbol,
       signed, price, marginPerUnit * qty,
       meta.expiry || null, meta.lotSize || null, meta.instrumentType || null,
       meta.strike || null, tradeDate]
    );
    openedQty = qty;
    const [[fresh]] = await conn.query('SELECT * FROM app_positions WHERE id=?', [ins.insertId]);
    return { realisedPnl: 0, closedQty: 0, openedQty, position: fresh };
  }

  const oldQty = pos.qty;
  const oldAvg = parseFloat(pos.avg_price);
  const newQty = oldQty + signed;

  const sameDirection = (oldQty >= 0 && signed > 0) || (oldQty <= 0 && signed < 0);

  if (sameDirection || oldQty === 0) {
    // Adding to the position: weighted average cost.
    const totalAbs = Math.abs(oldQty) + qty;
    const newAvg = ((oldAvg * Math.abs(oldQty)) + (price * qty)) / totalAbs;
    openedQty = qty;
    await conn.query(
      'UPDATE app_positions SET qty=?, avg_price=?, margin_blocked = margin_blocked + ? WHERE id=?',
      [newQty, newAvg.toFixed(4), marginPerUnit * qty, pos.id]
    );
  } else {
    // Reducing, closing, or flipping.
    const reducing = Math.min(qty, Math.abs(oldQty));
    closedQty = reducing;

    // A long closes by selling above cost; a short closes by buying
    // below it. The sign handles both without a branch.
    realisedPnl = oldQty > 0
      ? (price - oldAvg) * reducing
      : (oldAvg - price) * reducing;

    const remainingOld = Math.abs(oldQty) - reducing;
    const flipQty      = qty - reducing;          // overshoot flips direction
    openedQty          = flipQty;

    // Release the margin that was held against the closed portion.
    const releasedMargin = Math.abs(oldQty) > 0
      ? parseFloat(pos.margin_blocked) * (reducing / Math.abs(oldQty))
      : 0;

    if (remainingOld === 0 && flipQty === 0) {
      await conn.query(
        "UPDATE app_positions SET qty=0, margin_blocked=0, realised_pnl = realised_pnl + ?, " +
        "status='CLOSED', closed_at=NOW(), close_reason='Closed by user' WHERE id=?",
        [realisedPnl.toFixed(4), pos.id]
      );
    } else if (flipQty > 0) {
      // Flipped: the old side is fully closed and a new opposite
      // position opens at this fill's price.
      await conn.query(
        'UPDATE app_positions SET qty=?, avg_price=?, margin_blocked=?, realised_pnl = realised_pnl + ? WHERE id=?',
        [signed > 0 ? flipQty : -flipQty, price,
         (marginPerUnit * flipQty).toFixed(4), realisedPnl.toFixed(4), pos.id]
      );
    } else {
      await conn.query(
        'UPDATE app_positions SET qty=?, margin_blocked = GREATEST(0, margin_blocked - ?), ' +
        'realised_pnl = realised_pnl + ? WHERE id=?',
        [newQty, releasedMargin.toFixed(4), realisedPnl.toFixed(4), pos.id]
      );
    }
  }

  const [[fresh]] = await conn.query('SELECT * FROM app_positions WHERE id=?', [pos.id]);
  return { realisedPnl, closedQty, openedQty, position: fresh };
}

/**
 * Margin to release when a position is reduced by `qty` units.
 * Proportional to the fraction of the position being closed.
 */
function marginReleaseFor(position, qty) {
  const abs = Math.abs(position.qty);
  if (!abs) return 0;
  return parseFloat(position.margin_blocked || 0) * (Math.min(qty, abs) / abs);
}

/**
 * Move DELIVERY and MTF positions bought on previous days into
 * app_holdings — the T+1 settlement step from item 5. Positions bought
 * TODAY stay in Positions; that is the whole distinction the app was
 * missing.
 */
async function settleDelivery() {
  const today = istDateString();
  const [rows] = await db.pool.query(
    "SELECT * FROM app_positions WHERE status='OPEN' AND segment='EQUITY' " +
    "AND product IN ('DELIVERY','MTF') AND qty > 0 AND trade_date < ?",
    [today]
  );
  if (!rows.length) return { settled: 0 };

  let settled = 0;
  for (const p of rows) {
    const conn = await db.pool.getConnection();
    try {
      await conn.beginTransaction();

      const [held] = await conn.query(
        'SELECT * FROM app_holdings WHERE user_id=? AND symbol=? AND product=? FOR UPDATE',
        [p.user_id, p.symbol, p.product]
      );
      const cost = parseFloat(p.avg_price) * p.qty;

      if (held.length) {
        const h      = held[0];
        const newQty = h.qty + p.qty;
        const newAvg = ((parseFloat(h.avg_price) * h.qty) + cost) / newQty;
        await conn.query(
          "UPDATE app_holdings SET qty=?, avg_price=?, settlement_status='SETTLED', " +
          't1_qty=0, settles_on=NULL, mtf_funded = mtf_funded + ? WHERE id=?',
          [newQty, newAvg.toFixed(4),
           p.product === 'MTF' ? (cost - parseFloat(p.margin_blocked)).toFixed(4) : 0, h.id]
        );
      } else {
        await conn.query(
          'INSERT INTO app_holdings (user_id, symbol, exchange, name, qty, settlement_status, ' +
          " t1_qty, settles_on, product, mtf_funded, avg_price) VALUES (?,?,?,?,?,'SETTLED',0,NULL,?,?,?)",
          [p.user_id, p.symbol, p.exchange, p.name, p.qty, p.product,
           p.product === 'MTF' ? (cost - parseFloat(p.margin_blocked)).toFixed(4) : 0,
           p.avg_price]
        );
      }

      await conn.query(
        "UPDATE app_positions SET status='CLOSED', closed_at=NOW(), " +
        "close_reason='Settled into holdings (T+1)' WHERE id=?", [p.id]
      );

      await conn.commit(); conn.release();
      settled++;
    } catch (e) {
      try { await conn.rollback(); } catch {}
      conn.release();
      logger.error(`settleDelivery position ${p.id}: ${e.message}`);
    }
  }
  logger.info(`settleDelivery: moved ${settled} position(s) into holdings`);
  return { settled };
}

module.exports = {
  applyFill,
  settleDelivery,
  marginReleaseFor,
  istDateString,
  nextSettlementDate,
};
