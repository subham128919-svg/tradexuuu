// optionChainService.js
//
// CHANGED: subscribes the chain to the websocket feed so it streams
// live; passes through the full Kite data set (OI, volume, bid/ask,
// prevClose, OHLC) instead of only ltp/change/changePct; forwards
// changeAvailable so untraded strikes show a dash rather than a fake
// 0.00%; returns atmStrike / atmIndex / per-row isAtm so the app can
// scroll straight to the money; and falls back to the last stored
// candle when the live spot is unavailable. See README items 1 and 2.
const db                = require('../config/database');
const marketDataService = require('./marketDataService');
const { logger }        = require('../config/logger');

const INDEX_UNDERLYINGS = ['NIFTY','BANKNIFTY','FINNIFTY','MIDCPNIFTY','SENSEX','BANKEX'];
const SPOT_SYMBOL_MAP = {
  NIFTY: 'NIFTY 50', BANKNIFTY: 'NIFTY BANK', FINNIFTY: 'NIFTY FIN SERVICE',
  MIDCPNIFTY: 'NIFTY MIDCAP 100', SENSEX: 'SENSEX', BANKEX: 'BANKEX',
};

function isIndexUnderlying(u) { return INDEX_UNDERLYINGS.includes((u || '').toUpperCase()); }

async function getEffectiveLotSize(underlying, kiteLotSize) {
  try {
    const [[row]] = await db.pool.query(
      'SELECT lot_size FROM lot_size_overrides WHERE underlying = ?',
      [(underlying || '').toUpperCase()]);
    if (row && row.lot_size > 0) return row.lot_size;
  } catch {}
  return kiteLotSize;
}

async function getLotSizeForSymbol(tradingsymbol) {
  const [[row]] = await db.pool.query(
    "SELECT underlying, lot_size FROM instruments WHERE tradingsymbol = ? AND exchange = 'NFO' LIMIT 1",
    [tradingsymbol]);
  if (!row) return null;
  return getEffectiveLotSize(row.underlying, row.lot_size);
}

async function getExpiries(underlying) {
  const [rows] = await db.pool.query(
    "SELECT DISTINCT DATE_FORMAT(expiry, '%Y-%m-%d') AS expiry FROM instruments " +
    "WHERE underlying = ? AND exchange = 'NFO' AND expiry >= CURDATE() ORDER BY expiry ASC LIMIT 12",
    [underlying.toUpperCase()]);
  return rows.map(r => r.expiry);
}

async function resolveSpot(underlying) {
  const u = underlying.toUpperCase();
  const spotExchange = ['SENSEX','BANKEX'].includes(u) ? 'BSE' : 'NSE';
  const spotSymbol = spotExchange + ':' + (SPOT_SYMBOL_MAP[u] || u);
  try {
    const { ticks } = await marketDataService.getQuotesSmart([spotSymbol]);
    const ltp = ticks[spotSymbol]?.ltp;
    if (ltp > 0) return { spot: ltp, spotSymbol, spotStale: false };
  } catch (e) {
    logger.warn('optionChain.resolveSpot live failed for ' + spotSymbol + ': ' + e.message);
  }
  // A slightly stale spot beats a null one — the header and ATM
  // detection both need a number.
  try {
    const [rows] = await db.pool.query(
      'SELECT close FROM candles WHERE symbol = ? ORDER BY candle_time DESC LIMIT 1', [spotSymbol]);
    if (rows.length) return { spot: parseFloat(rows[0].close), spotSymbol, spotStale: true };
  } catch {}
  return { spot: null, spotSymbol, spotStale: true };
}

function buildContract(c, tick) {
  if (!tick) {
    return {
      symbol: c.tradingsymbol, ltp: 0, change: 0, changePct: 0,
      changeAvailable: false, prevClose: 0, open: 0, high: 0, low: 0,
      volume: 0, oi: 0, bid: 0, ask: 0, bidQty: 0, askQty: 0,
      depth: null, priceAvailable: false,
    };
  }
  return {
    symbol: c.tradingsymbol,
    ltp: tick.ltp || 0,
    change: tick.change || 0,
    changePct: tick.changePct || 0,
    changeAvailable: tick.changeAvailable !== false && (tick.close || 0) > 0,
    prevClose: tick.close || 0,
    open: tick.open || 0, high: tick.high || 0, low: tick.low || 0,
    volume: tick.volume || 0, oi: tick.oi || 0,
    bid: tick.bid || 0, ask: tick.ask || 0,
    bidQty: tick.bidQty || 0, askQty: tick.askQty || 0,
    depth: tick.depth || null,
    priceAvailable: (tick.ltp || 0) > 0,
  };
}

async function getChain(underlying, expiry) {
  const [contracts] = await db.pool.query(
    'SELECT tradingsymbol, instrument_type, strike, lot_size FROM instruments ' +
    "WHERE underlying = ? AND exchange = 'NFO' AND expiry = ? " +
    "AND instrument_type IN ('CE','PE') ORDER BY strike ASC",
    [underlying.toUpperCase(), expiry]);

  if (!contracts.length) {
    return { underlying, expiry, lotSize: null, spot: null, spotStale: true,
             atmStrike: null, atmIndex: -1, rows: [], live: false };
  }

  const lotSize = await getEffectiveLotSize(underlying, contracts[0].lot_size);
  const symbols = contracts.map(c => 'NFO:' + c.tradingsymbol);

  // Live feed: no 500-instrument cap, no per-second rate limit.
  let live = false;
  try {
    const ticker = require('./kiteTicker');
    await ticker.subscribe(symbols, { full: true });
    live = ticker.isLive();
  } catch (e) {
    logger.warn('optionChain: ticker subscribe failed: ' + e.message);
  }

  // Still seed from REST so the first open is instant and so there is a
  // fallback whenever the ticker is down. It is chunked now.
  const { ticks } = await marketDataService.getQuotesSmart(symbols).catch(err => {
    logger.warn('optionChain: quote fetch failed: ' + err.message);
    return { ticks: {} };
  });

  const { spot, spotStale } = await resolveSpot(underlying);

  const byStrike = new Map();
  contracts.forEach(c => {
    const key = String(c.strike);
    if (!byStrike.has(key)) {
      byStrike.set(key, { strike: parseFloat(c.strike), call: null, put: null, isAtm: false });
    }
    const contract = buildContract(c, ticks['NFO:' + c.tradingsymbol]);
    if (c.instrument_type === 'CE') byStrike.get(key).call = contract;
    else                            byStrike.get(key).put  = contract;
  });

  const rows = [...byStrike.values()].sort((a, b) => a.strike - b.strike);

  // ATM: nearest strike to spot. Drives the app's auto-scroll.
  let atmIndex = -1, atmStrike = null;
  if (spot != null && rows.length) {
    let best = Infinity;
    rows.forEach((r, i) => {
      const d = Math.abs(r.strike - spot);
      if (d < best) { best = d; atmIndex = i; }
    });
    if (atmIndex >= 0) { atmStrike = rows[atmIndex].strike; rows[atmIndex].isAtm = true; }
  }

  return { underlying, expiry, lotSize, spot, spotStale, atmStrike, atmIndex, rows, live };
}

// Called when the app leaves the chain screen, so the ticker can
// release those instruments back to the subscription budget.
async function releaseChain(underlying, expiry) {
  try {
    const [contracts] = await db.pool.query(
      "SELECT tradingsymbol FROM instruments WHERE underlying = ? AND exchange = 'NFO' " +
      "AND expiry = ? AND instrument_type IN ('CE','PE')",
      [underlying.toUpperCase(), expiry]);
    if (!contracts.length) return;
    await require('./kiteTicker').unsubscribe(contracts.map(c => 'NFO:' + c.tradingsymbol));
  } catch {}
}

module.exports = {
  getExpiries, getChain, releaseChain, isIndexUnderlying,
  getEffectiveLotSize, getLotSizeForSymbol, resolveSpot,
};
