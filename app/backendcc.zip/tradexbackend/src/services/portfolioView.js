// portfolioView.js — NEW. Item 5.
//
// Builds the Positions and Holdings views with live P&L, keeping
// Equity and F&O separate. Before this there was one undifferentiated
// list derived from app_holdings, so a same-day intraday trade, a
// carried-forward F&O position and a settled delivery holding all
// looked identical.
//
// Positions = today's trades + anything still unsettled + every open
//             F&O position (which carries overnight).
// Holdings  = delivery/MTF equity that has settled into the demat.
const db                = require('../config/database');
const marketDataService = require('./marketDataService');

function key(symbol, exchange) {
  return symbol.includes(':') ? symbol : `${exchange || 'NSE'}:${symbol}`;
}

async function quoteMap(keys) {
  if (!keys.length) return {};
  const { ticks } = await marketDataService.getQuotesSmart(keys).catch(() => ({ ticks: {} }));
  return ticks;
}

// Last stored close, used when the live quote is unavailable so P&L
// shows a real number rather than -100% computed against an ltp of 0.
async function fallbackClose(k) {
  try {
    const [rows] = await db.pool.query(
      'SELECT close FROM candles WHERE symbol=? ORDER BY candle_time DESC LIMIT 1', [k]);
    if (rows.length) return parseFloat(rows[0].close);
  } catch {}
  return 0;
}

/**
 * segment: 'EQUITY' | 'FNO' | null (both)
 */
async function positions(userId, segment) {
  const params = [userId];
  let sql = "SELECT * FROM app_positions WHERE user_id=? AND status IN ('OPEN','SQUAREOFF_FAILED') AND qty <> 0";
  if (segment) { sql += ' AND segment=?'; params.push(segment); }
  sql += ' ORDER BY opened_at DESC';
  const [rows] = await db.pool.query(sql, params);

  const keys  = rows.map(p => key(p.symbol, p.exchange));
  const ticks = await quoteMap(keys);

  let invested = 0, current = 0, realised = 0;

  const out = await Promise.all(rows.map(async p => {
    const k = key(p.symbol, p.exchange);
    let ltp = ticks[k]?.ltp || 0;
    let priceAvailable = ltp > 0;
    if (!priceAvailable) { ltp = await fallbackClose(k); priceAvailable = ltp > 0; }

    const absQty = Math.abs(p.qty);
    const isLong = p.qty > 0;
    const avg    = parseFloat(p.avg_price);
    const inv    = avg * absQty;
    const cur    = priceAvailable ? ltp * absQty : inv;
    // A short profits when price falls, so the sign flips.
    const unreal = priceAvailable ? (isLong ? cur - inv : inv - cur) : 0;
    const rpnl   = parseFloat(p.realised_pnl || 0);

    invested += inv; current += cur; realised += rpnl;

    return {
      id: p.id, symbol: k, rawSymbol: p.symbol, exchange: p.exchange,
      segment: p.segment, product: p.product, name: p.name,
      qty: p.qty, absQty, side: isLong ? 'LONG' : 'SHORT',
      avgPrice: avg, ltp,
      invested: +inv.toFixed(2), currentValue: +cur.toFixed(2),
      pnl: +unreal.toFixed(2),
      pnlPct: inv > 0 ? +((unreal / inv) * 100).toFixed(2) : 0,
      realisedPnl: +rpnl.toFixed(2),
      marginBlocked: +parseFloat(p.margin_blocked || 0).toFixed(2),
      isProfit: unreal >= 0,
      priceAvailable,
      expiry: p.expiry, lotSize: p.lot_size,
      instrumentType: p.instrument_type, strike: p.strike,
      status: p.status,
      // Surfaced so the app can warn rather than silently showing an
      // intraday position that should have been closed at the cutoff.
      squareOffFailed: p.status === 'SQUAREOFF_FAILED',
      failReason: p.status === 'SQUAREOFF_FAILED' ? p.close_reason : null,
      tradeDate: p.trade_date,
    };
  }));

  const totalPnl = current - invested;
  return {
    positions: out,
    totals: {
      invested: +invested.toFixed(2),
      currentValue: +current.toFixed(2),
      totalPnl: +totalPnl.toFixed(2),
      totalPnlPct: invested > 0 ? +((totalPnl / invested) * 100).toFixed(2) : 0,
      realisedPnl: +realised.toFixed(2),
    },
  };
}

async function holdings(userId) {
  const [rows] = await db.pool.query(
    'SELECT * FROM app_holdings WHERE user_id=? AND qty>0 ORDER BY symbol ASC', [userId]);
  const keys  = rows.map(h => key(h.symbol, h.exchange));
  const ticks = await quoteMap(keys);

  let invested = 0, current = 0;

  const out = await Promise.all(rows.map(async h => {
    const k = key(h.symbol, h.exchange);
    let ltp = ticks[k]?.ltp || 0;
    let priceAvailable = ltp > 0;
    if (!priceAvailable) { ltp = await fallbackClose(k); priceAvailable = ltp > 0; }

    const avg = parseFloat(h.avg_price);
    const inv = avg * h.qty;
    const cur = priceAvailable ? ltp * h.qty : inv;
    const pnl = cur - inv;
    invested += inv; current += cur;

    return {
      symbol: k, rawSymbol: h.symbol, exchange: h.exchange, name: h.name,
      qty: h.qty, avgPrice: avg, ltp,
      invested: +inv.toFixed(2), currentValue: +cur.toFixed(2),
      pnl: +pnl.toFixed(2),
      pnlPct: inv > 0 ? +((pnl / inv) * 100).toFixed(2) : 0,
      isProfit: pnl >= 0, priceAvailable,
      product: h.product,
      settlementStatus: h.settlement_status,
      t1Qty: h.t1_qty || 0,
      settlesOn: h.settles_on,
      mtfFunded: +parseFloat(h.mtf_funded || 0).toFixed(2),
    };
  }));

  const totalPnl = current - invested;
  return {
    holdings: out,
    totals: {
      invested: +invested.toFixed(2),
      currentValue: +current.toFixed(2),
      totalPnl: +totalPnl.toFixed(2),
      totalPnlPct: invested > 0 ? +((totalPnl / invested) * 100).toFixed(2) : 0,
    },
  };
}

module.exports = { positions, holdings };
