// marketDataService.js
//
// CHANGED: change% was computed as net_change / (close || 1). When
// previous close is 0 — the normal state for a strike that has not
// traded today — that divides by one rupee, so a 12.50 move reported
// as +1250%. That is the percentage bug. We now report 0 and expose
// changeAvailable so the app can render a dash. Ticks also carry oi,
// volume, bid/ask and depth, and the ticker is consulted so streamed
// symbols do not burn a rate-limited REST call. See README "Item 2".
const kite                = require('./kiteService');
const tickCache           = require('./tickCache');
const { getMarketStatus } = require('./marketStatusService');
const { logger }          = require('../config/logger');

const LIVE_POLL_STALE_MS = 3000;
// Websocket ticks push on change, not on an interval, so an illiquid
// strike legitimately goes quiet for a while. Allow for that.
const TICKER_STALE_MS = 15_000;

function normalizeQuote(sym, q) {
  const close = Number(q.ohlc?.close) || 0;
  const ltp   = Number(q.last_price)  || 0;
  const raw   = Number(q.net_change);
  const change = Number.isFinite(raw) && raw !== 0 ? raw : (close > 0 ? ltp - close : 0);
  const changeAvailable = close > 0 && ltp > 0;
  const changePct = changeAvailable ? parseFloat(((ltp - close) / close * 100).toFixed(2)) : 0;
  const depth = q.depth || null;
  return {
    symbol: sym, ltp,
    open: Number(q.ohlc?.open) || 0,
    high: Number(q.ohlc?.high) || 0,
    low:  Number(q.ohlc?.low)  || 0,
    close,
    change: changeAvailable ? parseFloat(Number(change).toFixed(2)) : 0,
    changePct, changeAvailable,
    volume: Number(q.volume ?? q.volume_traded) || 0,
    oi: Number(q.oi) || 0,
    avgPrice: Number(q.average_price) || 0,
    lowerCircuit: Number(q.lower_circuit_limit) || 0,
    upperCircuit: Number(q.upper_circuit_limit) || 0,
    bid: Number(depth?.buy?.[0]?.price) || 0,
    ask: Number(depth?.sell?.[0]?.price) || 0,
    bidQty: Number(depth?.buy?.[0]?.quantity) || 0,
    askQty: Number(depth?.sell?.[0]?.quantity) || 0,
    depth: depth ? { buy: depth.buy || [], sell: depth.sell || [] } : null,
    updatedAt: Date.now(),   // Unix ms, not an ISO string
  };
}

async function getQuotesSmart(symbols) {
  const status = getMarketStatus();
  if (!symbols || !symbols.length) return { ticks: {}, marketStatus: status };

  const cached = await tickCache.getTicks(symbols);
  const now = Date.now();

  let ticker = null, tickerLive = false;
  try { ticker = require('./kiteTicker'); tickerLive = ticker.isLive(); } catch {}

  const staleMs = (sym) =>
    tickerLive && ticker.symbolToken.has(sym) ? TICKER_STALE_MS : LIVE_POLL_STALE_MS;

  const needsFresh = status.isOpen
    ? symbols.filter(s => !cached[s] || (now - (cached[s].updatedAt || 0)) > staleMs(s))
    : symbols.filter(s => !cached[s]);

  if (needsFresh.length) {
    try {
      const fresh = await kite.getQuotes(needsFresh);
      for (const [sym, q] of Object.entries(fresh)) {
        const tick = normalizeQuote(sym, q);
        await tickCache.setTick(sym, tick);
        cached[sym] = tick;
      }
    } catch (err) {
      logger.warn('getQuotesSmart: Kite fetch failed, serving cache -- ' + err.message);
    }
  }
  return { ticks: cached, marketStatus: status };
}

module.exports = { getQuotesSmart, normalizeQuote };
