// kiteService.js — Zerodha Kite Connect wrapper.
//
// CHANGED: getQuotes() is now CHUNKED and no longer mutates the
// caller's array. Kite caps /quote at 500 instruments; the old version
// passed the whole option chain in one call, Kite rejected it, and
// optionChainService fell back to {} — which is why every strike showed
// 0 price / 0 change / 0 percent. Chunks now fail independently.
// See README "Item 2". Everything else is unchanged.
const { KiteConnect } = require('kiteconnect');
const redis           = require('../config/redis');
const { logger }      = require('../config/logger');

const kite = new KiteConnect({ api_key: process.env.KITE_API_KEY || '' });

// Documented ceiling is 500. 200 keeps each response inside Kite's
// size and timeout budget, since chain quotes carry depth.
const QUOTE_CHUNK = 200;

function setAccessToken(token) {
  kite.setAccessToken(token);
  logger.info('Kite access token set');
}

async function restoreSession() {
  try {
    const token = await redis.get('kite:access_token');
    if (token) { kite.setAccessToken(token); logger.info('Kite session restored from cache'); }
    else logger.warn('No Kite access token in cache — login at /api/v1/auth/kite-login');
  } catch (e) { logger.warn('Could not restore Kite session:', e.message); }
}
restoreSession();

function chunk(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

async function getQuotes(symbols) {
  if (!symbols || !symbols.length) return {};
  // slice() first — the old symbols.sort() sorted the caller's array in place.
  const cacheKey = `quotes:${[...symbols].sort().join(',')}`;
  try {
    const cached = await redis.get(cacheKey);
    if (cached) return JSON.parse(cached);
  } catch {}

  const batches = chunk(symbols, QUOTE_CHUNK);
  const settled = await Promise.allSettled(batches.map(b => kite.getQuote(b)));

  const quotes = {};
  let failed = 0;
  settled.forEach((r, i) => {
    if (r.status === 'fulfilled' && r.value) Object.assign(quotes, r.value);
    else {
      failed++;
      logger.warn(`kiteService.getQuotes: chunk ${i + 1}/${batches.length} failed ` +
                  `(${batches[i].length} symbols) — ${r.reason?.message || r.reason}`);
    }
  });
  if (failed === batches.length) {
    throw new Error('All quote chunks failed (Kite unreachable or token expired)');
  }
  try { await redis.set(cacheKey, JSON.stringify(quotes), 'EX', 2); } catch {}
  return quotes;
}

async function getInstrumentToken(exchange, symbol) {
  const cacheKey = `token:${exchange}:${symbol}`;
  try {
    const cached = await redis.get(cacheKey);
    if (cached) return parseInt(cached, 10);
  } catch {}
  const key = `${exchange}:${symbol}`;
  const quotes = await kite.getQuote([key]);
  const q = quotes[key];
  if (!q) throw new Error(`Instrument not found: ${key}`);
  const token = q.instrument_token;
  try { await redis.set(cacheKey, String(token), 'EX', 86400); } catch {}
  logger.info(`Instrument token for ${key}: ${token}`);
  return token;
}

async function getCandles(instrumentToken, interval, from, to) {
  const cacheKey = `candles:${instrumentToken}:${interval}:${from}:${to}`;
  try {
    const cached = await redis.get(cacheKey);
    if (cached) return JSON.parse(cached);
  } catch {}
  const data = await kite.getHistoricalData(instrumentToken, interval, from, to);
  const candles = data.map(c => ({
    time: Math.floor(new Date(c.date).getTime() / 1000),
    open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume || 0,
  }));
  const ttl = interval === 'day' || interval === 'week' ? 3600 : 60;
  try { await redis.set(cacheKey, JSON.stringify(candles), 'EX', ttl); } catch {}
  return candles;
}

async function searchInstruments(query, exchange = 'NSE') {
  return [{ symbol: query.toUpperCase(), exchange, name: query.toUpperCase() }];
}

async function getHoldings() {
  const holdings = await kite.getHoldings();
  return holdings.map(h => ({
    symbol: h.tradingsymbol, exchange: h.exchange, quantity: h.quantity,
    avgCost: h.average_price, currentPrice: h.last_price,
    currentValue: h.quantity * h.last_price, pnl: h.pnl,
    pnlPercent: h.average_price > 0 ? ((h.last_price - h.average_price) / h.average_price * 100) : 0,
    instrumentToken: h.instrument_token,
  }));
}

async function getPositions() {
  const { day, net } = await kite.getPositions();
  const fmt = p => ({
    symbol: p.tradingsymbol, exchange: p.exchange, product: p.product,
    quantity: p.quantity, avgCost: p.average_price, lastPrice: p.last_price,
    pnl: p.pnl, unrealised: p.unrealised, realised: p.realised,
  });
  return { day: day.map(fmt), net: net.map(fmt) };
}

async function getOrders() {
  const orders = await kite.getOrders();
  return orders.map(o => ({
    id: o.order_id, symbol: o.tradingsymbol, exchange: o.exchange,
    type: o.transaction_type, product: o.product, orderType: o.order_type,
    quantity: o.quantity, filledQuantity: o.filled_quantity, price: o.price,
    avgPrice: o.average_price, status: o.status, timestamp: o.order_timestamp,
  }));
}

async function placeOrder(params) {
  return kite.placeOrder(params.variety || 'regular', {
    exchange: params.exchange, tradingsymbol: params.symbol,
    transaction_type: params.transactionType, quantity: params.quantity,
    product: params.product, order_type: params.orderType, price: params.price || 0,
  });
}

module.exports = {
  kite, setAccessToken, getQuotes, getInstrumentToken, getCandles,
  searchInstruments, getHoldings, getPositions, getOrders, placeOrder,
};
