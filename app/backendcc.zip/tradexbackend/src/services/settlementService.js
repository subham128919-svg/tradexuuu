// settlementService.js — NEW. Item 7.
//
// Two scheduled jobs, deliberately kept separate because they fail
// differently and must not be confused with each other:
//
//   1. runIntradaySquareOff()  at 15:15 IST
//      Exits every open INTRADAY position at an executable market price,
//      through the same depth matcher a user order goes through. If the
//      book cannot absorb the exit, the position is marked
//      SQUAREOFF_FAILED — NOT squared off. Your spec was explicit about
//      this: an unsuccessful exit must never be recorded as completed.
//
//   2. runExpirySettlement()   after close on expiry day
//      Cash-settles every open F&O position, per your decision that
//      stock options are cash settled here too rather than going to
//      physical delivery. Three outcomes are distinguished:
//        EXPIRY_CASH       — in the money, settled at intrinsic value
//        EXPIRY_WORTHLESS  — out of the money, premium lost in full
//        (a short that expires worthless keeps the premium — same path,
//         the sign of the position handles it)
//
// Both jobs are idempotent per day: a position already CLOSED, EXPIRED
// or SQUARED_OFF is skipped, so a retry after a crash cannot double-settle.

const db                  = require('../config/database');
const settings            = require('../utils/settings');
const exec                = require('./executionService');
const positionService     = require('./positionService');
const optionChainService  = require('./optionChainService');
const marketDataService   = require('./marketDataService');
const { logger }          = require('../config/logger');

const { istDateString } = positionService;

async function audit(conn, row) {
  const q = conn || db.pool;
  await q.query(
    'INSERT INTO app_settlements (user_id, position_id, symbol, kind, qty, price, pnl, ' +
    ' result, detail, run_date) VALUES (?,?,?,?,?,?,?,?,?,?)',
    [row.userId, row.positionId || null, row.symbol, row.kind, row.qty || 0,
     row.price ?? null, row.pnl || 0, row.result || 'SUCCESS',
     (row.detail || '').slice(0, 400), istDateString()]
  );
}

// ═══════════════════════════════════════════════════════════════
//  1. INTRADAY SQUARE-OFF
// ═══════════════════════════════════════════════════════════════

async function runIntradaySquareOff() {
  const today = istDateString();
  const [positions] = await db.pool.query(
    "SELECT * FROM app_positions WHERE status='OPEN' AND product='INTRADAY' " +
    'AND qty <> 0 AND trade_date = ?',
    [today]
  );
  if (!positions.length) {
    logger.info('square-off: nothing open');
    return { attempted: 0, squared: 0, failed: 0 };
  }

  logger.info(`square-off: ${positions.length} intraday position(s) to exit`);
  let squared = 0, failed = 0;

  for (const p of positions) {
    try {
      const ok = await squareOffPosition(p);
      ok ? squared++ : failed++;
    } catch (e) {
      failed++;
      logger.error(`square-off position ${p.id}: ${e.message}`);
      await audit(null, {
        userId: p.user_id, positionId: p.id, symbol: p.symbol,
        kind: 'INTRADAY_SQUAREOFF', qty: Math.abs(p.qty),
        result: 'FAILED', detail: e.message,
      }).catch(() => {});
      await db.pool.query(
        "UPDATE app_positions SET status='SQUAREOFF_FAILED', close_reason=? WHERE id=?",
        [('Square-off failed: ' + e.message).slice(0, 120), p.id]
      ).catch(() => {});
    }
  }

  logger.info(`square-off complete: ${squared} squared, ${failed} failed`);
  return { attempted: positions.length, squared, failed };
}

async function squareOffPosition(p) {
  const exitSide = p.qty > 0 ? 'SELL' : 'BUY';
  const exitQty  = Math.abs(p.qty);

  const book = await exec.getBook(p.symbol, p.exchange);
  if (!book) {
    await markFailed(p, 'No live market data at square-off time');
    return false;
  }

  // Market exit: walk the book from the best price, bounded only by the
  // circuit band. No limit — this is a forced exit.
  const bound = exec.marketBound(book, exitSide);
  const { fills, filledQty } = exec.matchAgainstBook(book, exitSide, exitQty, bound);

  if (!filledQty) {
    await markFailed(p,
      'No executable quantity available in the book at square-off time');
    return false;
  }

  const conn = await db.pool.getConnection();
  try {
    await conn.beginTransaction();

    const [[fresh]] = await conn.query(
      'SELECT * FROM app_positions WHERE id=? FOR UPDATE', [p.id]);
    if (!fresh || fresh.status !== 'OPEN' || fresh.qty === 0) {
      await conn.rollback(); conn.release();
      return true;    // already handled — idempotent, not a failure
    }

    const value   = fills.reduce((s, f) => s + f.qty * f.price, 0);
    const avgExit = value / filledQty;

    // Record the exit as a real order + trades so it appears in Orders
    // with the same shape as a user-placed exit.
    const [ord] = await conn.query(
      'INSERT INTO app_orders (user_id, symbol, exchange, segment, name, order_type, product, ' +
      " price_type, qty, filled_qty, price, avg_price, blocked_amount, status) " +
      "VALUES (?,?,?,?,?,?,?,'MARKET',?,?,?,?,0,'EXECUTED')",
      [fresh.user_id, fresh.symbol, fresh.exchange, fresh.segment,
       fresh.name, exitSide, 'INTRADAY', filledQty, filledQty,
       avgExit.toFixed(4), avgExit.toFixed(4)]
    );
    for (const f of fills) {
      await conn.query(
        'INSERT INTO app_trades (order_id, user_id, symbol, exchange, side, qty, price, depth_level) ' +
        'VALUES (?,?,?,?,?,?,?,?)',
        [ord.insertId, fresh.user_id, fresh.symbol, fresh.exchange,
         exitSide, f.qty, f.price, f.level]
      );
    }

    const res = await positionService.applyFill(conn, {
      userId: fresh.user_id, symbol: fresh.symbol, exchange: fresh.exchange,
      segment: fresh.segment, product: 'INTRADAY', name: fresh.name,
      side: exitSide, qty: filledQty, price: avgExit, marginPerUnit: 0,
    });

    // Return the margin held against the closed portion, plus the P&L.
    const release = positionService.marginReleaseFor(fresh, filledQty);
    const credit  = release + res.realisedPnl;
    if (Math.abs(credit) > 0.0001) {
      await conn.query('UPDATE app_wallet SET balance = balance + ? WHERE user_id=?',
        [credit, fresh.user_id]);
      await conn.query(
        'INSERT INTO wallet_transactions (user_id, type, amount, note, done_by) VALUES (?,?,?,?,?)',
        [fresh.user_id, credit >= 0 ? 'credit' : 'debit', Math.abs(credit),
         `Intraday square-off ${fresh.symbol}: margin released ₹${release.toFixed(2)}, ` +
         `P&L ₹${res.realisedPnl.toFixed(2)}`, 'system']
      );
    }

    // A partial exit leaves the rest OPEN and flagged — it is not done.
    const fullyExited = filledQty >= exitQty;
    await conn.query(
      'UPDATE app_positions SET status=?, closed_at=?, close_reason=? WHERE id=?',
      fullyExited
        ? ['SQUARED_OFF', new Date(), 'Auto square-off at cutoff', fresh.id]
        : ['SQUAREOFF_FAILED', null,
           `Partial square-off: ${filledQty} of ${exitQty} exited`, fresh.id]
    );

    await audit(conn, {
      userId: fresh.user_id, positionId: fresh.id, symbol: fresh.symbol,
      kind: 'INTRADAY_SQUAREOFF', qty: filledQty, price: avgExit,
      pnl: res.realisedPnl,
      result: fullyExited ? 'SUCCESS' : 'FAILED',
      detail: fullyExited
        ? `Exited ${filledQty} @ avg ₹${avgExit.toFixed(2)}`
        : `Only ${filledQty} of ${exitQty} could be exited — ${exitQty - filledQty} still open`,
    });

    await conn.commit(); conn.release();
    return fullyExited;
  } catch (e) {
    try { await conn.rollback(); } catch {}
    conn.release();
    throw e;
  }
}

async function markFailed(p, reason) {
  await db.pool.query(
    "UPDATE app_positions SET status='SQUAREOFF_FAILED', close_reason=? WHERE id=?",
    [reason.slice(0, 120), p.id]
  );
  await audit(null, {
    userId: p.user_id, positionId: p.id, symbol: p.symbol,
    kind: 'INTRADAY_SQUAREOFF', qty: Math.abs(p.qty),
    result: 'FAILED', detail: reason,
  });
  logger.warn(`square-off FAILED for position ${p.id} (${p.symbol}): ${reason}`);
}

// ═══════════════════════════════════════════════════════════════
//  2. EXPIRY SETTLEMENT
// ═══════════════════════════════════════════════════════════════

async function runExpirySettlement(forDate) {
  const day = forDate || istDateString();
  const [positions] = await db.pool.query(
    "SELECT * FROM app_positions WHERE status='OPEN' AND segment='FNO' " +
    'AND qty <> 0 AND expiry IS NOT NULL AND expiry <= ?',
    [day]
  );
  if (!positions.length) {
    logger.info('expiry settlement: nothing to settle');
    return { settled: 0, worthless: 0, failed: 0 };
  }

  logger.info(`expiry settlement: ${positions.length} position(s) expiring on or before ${day}`);
  let settled = 0, worthless = 0, failed = 0;

  for (const p of positions) {
    try {
      const r = await settleExpiredPosition(p);
      if (r === 'WORTHLESS') worthless++; else settled++;
    } catch (e) {
      failed++;
      logger.error(`expiry settlement position ${p.id}: ${e.message}`);
      await audit(null, {
        userId: p.user_id, positionId: p.id, symbol: p.symbol,
        kind: 'EXPIRY_CASH', qty: Math.abs(p.qty),
        result: 'FAILED', detail: e.message,
      }).catch(() => {});
    }
  }

  logger.info(`expiry settlement: ${settled} cash-settled, ${worthless} worthless, ${failed} failed`);
  return { settled, worthless, failed };
}

/**
 * Intrinsic value per unit at expiry. Everything is cash settled per
 * your decision, index and stock alike.
 *   CE:  max(0, spot - strike)
 *   PE:  max(0, strike - spot)
 *   FUT: spot (settled against the final price)
 */
function intrinsicValue(instrumentType, strike, spot) {
  const t = String(instrumentType || '').toUpperCase();
  if (t === 'CE')  return Math.max(0, spot - strike);
  if (t === 'PE')  return Math.max(0, strike - spot);
  return spot;    // futures
}

// Underlying for a contract: prefer the instruments table, which is
// authoritative, and fall back to parsing the trading symbol.
async function underlyingFor(symbol) {
  try {
    const [[row]] = await db.pool.query(
      "SELECT underlying, instrument_type, strike FROM instruments " +
      "WHERE tradingsymbol = ? AND exchange IN ('NFO','BFO') LIMIT 1",
      [symbol]
    );
    if (row) return row;
  } catch {}
  const m = /^([A-Z]+)/.exec(symbol);
  return { underlying: m ? m[1] : null, instrument_type: null, strike: null };
}

async function settleExpiredPosition(p) {
  const info       = await underlyingFor(p.symbol);
  const underlying = info.underlying;
  const itype      = p.instrument_type || info.instrument_type;
  const strike     = parseFloat(p.strike ?? info.strike ?? 0);

  if (!underlying) throw new Error('Could not resolve underlying for ' + p.symbol);

  const { spot } = await optionChainService.resolveSpot(underlying);
  if (spot == null || spot <= 0) {
    throw new Error('No settlement price available for ' + underlying);
  }

  const perUnit  = intrinsicValue(itype, strike, spot);
  const qty      = Math.abs(p.qty);
  const isLong   = p.qty > 0;
  const avg      = parseFloat(p.avg_price);

  // Long:  pays premium, receives intrinsic   -> (intrinsic - premium)
  // Short: receives premium, pays intrinsic   -> (premium - intrinsic)
  const pnl      = (isLong ? (perUnit - avg) : (avg - perUnit)) * qty;
  const isWorthless = perUnit <= 0;

  const conn = await db.pool.getConnection();
  try {
    await conn.beginTransaction();

    const [[fresh]] = await conn.query(
      'SELECT * FROM app_positions WHERE id=? FOR UPDATE', [p.id]);
    if (!fresh || fresh.status !== 'OPEN') {
      await conn.rollback(); conn.release();
      return isWorthless ? 'WORTHLESS' : 'CASH';
    }

    // Credit back the margin held, plus settlement proceeds.
    // For a long, the premium is already spent, so only the intrinsic
    // value comes back. For a short, the margin returns and the
    // intrinsic value is paid away.
    const margin   = parseFloat(fresh.margin_blocked || 0);
    const proceeds = isLong ? (perUnit * qty) : (margin - perUnit * qty);
    const credit   = isLong ? (margin + proceeds - margin) + 0 : proceeds;
    const net      = isLong ? perUnit * qty : Math.max(0, margin - perUnit * qty);

    if (net > 0.0001) {
      await conn.query('UPDATE app_wallet SET balance = balance + ? WHERE user_id=?',
        [net, fresh.user_id]);
      await conn.query(
        'INSERT INTO wallet_transactions (user_id, type, amount, note, done_by) VALUES (?,?,?,?,?)',
        [fresh.user_id, 'credit', net,
         isWorthless
           ? `${fresh.symbol} expired worthless — ${isLong ? 'premium lost' : 'margin released, premium kept'}`
           : `${fresh.symbol} cash settled @ ₹${perUnit.toFixed(2)} (spot ₹${spot.toFixed(2)})`,
         'system']
      );
    }

    await conn.query(
      "UPDATE app_positions SET qty=0, margin_blocked=0, realised_pnl = realised_pnl + ?, " +
      "status='EXPIRED', closed_at=NOW(), close_reason=? WHERE id=?",
      [pnl.toFixed(4),
       isWorthless ? 'Expired worthless' : `Cash settled at ₹${perUnit.toFixed(2)}`,
       fresh.id]
    );

    await audit(conn, {
      userId: fresh.user_id, positionId: fresh.id, symbol: fresh.symbol,
      kind: isWorthless ? 'EXPIRY_WORTHLESS' : 'EXPIRY_CASH',
      qty, price: perUnit, pnl, result: 'SUCCESS',
      detail: `${itype || 'FUT'} strike ${strike}, settlement spot ₹${spot.toFixed(2)}, ` +
              `intrinsic ₹${perUnit.toFixed(2)}, ${isLong ? 'long' : 'short'} avg ₹${avg.toFixed(2)}`,
    });

    await conn.commit(); conn.release();
    return isWorthless ? 'WORTHLESS' : 'CASH';
  } catch (e) {
    try { await conn.rollback(); } catch {}
    conn.release();
    throw e;
  }
}

// ═══════════════════════════════════════════════════════════════
//  Scheduling
// ═══════════════════════════════════════════════════════════════
// Checked once a minute rather than with a cron expression, so the
// square-off time stays admin-editable at runtime without a restart.

let timer = null;
let lastRunKey = '';

async function tick() {
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
  const day = now.getDay();
  if (day === 0 || day === 6) return;

  const hhmm = String(now.getHours()).padStart(2, '0') + ':' +
               String(now.getMinutes()).padStart(2, '0');
  const target = await settings.get('intraday_squareoff_time', '15:15');

  if (hhmm === target) {
    const key = istDateString() + ':squareoff';
    if (lastRunKey === key) return;
    lastRunKey = key;
    await runIntradaySquareOff().catch(e => logger.error('square-off job: ' + e.message));
  }

  // After the close: settle expiries, then move yesterday's delivery
  // positions into holdings. Order matters — settle before migrating.
  if (hhmm === '15:45') {
    const key = istDateString() + ':eod';
    if (lastRunKey === key) return;
    lastRunKey = key;
    await runExpirySettlement().catch(e => logger.error('expiry job: ' + e.message));
    await positionService.settleDelivery().catch(e => logger.error('settle job: ' + e.message));
  }
}

function startSettlementJobs() {
  if (timer) return;
  timer = setInterval(() => tick().catch(() => {}), 60_000);
  logger.info('settlement jobs started (square-off + expiry + T+1)');
}
function stopSettlementJobs() { clearInterval(timer); timer = null; }

module.exports = {
  runIntradaySquareOff,
  runExpirySettlement,
  squareOffPosition,
  intrinsicValue,
  startSettlementJobs,
  stopSettlementJobs,
};
