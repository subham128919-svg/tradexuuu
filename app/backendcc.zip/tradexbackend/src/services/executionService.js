// executionService.js — NEW. Item 4 (and the engine items 3/5/7 use).
//
// Before this, a LIMIT order did:
//     execPrice = Number(price);   // whatever the user typed
//     ... status 'EXECUTED'
// No reference to the market at all. Buy anything at Rs.1, sell it at
// Rs.10,000, against a wallet funded with real money via Razorpay.
//
// Now every fill is matched against Kite's live 5-level depth streamed
// by kiteTicker:
//   BUY  fills against the ASK side, cheapest first, only at levels
//        priced <= the limit.
//   SELL fills against the BID side, highest first, only at levels
//        priced >= the limit.
// Each level's quantity caps what fills there, so a thin book produces
// a genuine partial fill and the rest stays PENDING for the retry loop.
// A MARKET order is a limit at the circuit band, so it walks the book
// and its average is a real VWAP rather than a single LTP.
//
// This does NOT place orders on Zerodha. What it guarantees is that no
// fill happens at a price, or in a quantity, that was not actually
// available in the live book at that moment. See README "Item 4".

const db                  = require('../config/database');
const tickCache           = require('./tickCache');
const marketDataService   = require('./marketDataService');
const marginService       = require('./marginService');
const positionService     = require('./positionService');
const { getMarketStatus } = require('./marketStatusService');
const { logger }          = require('../config/logger');

// Share of a level's displayed quantity one user may take. The book is
// shared with the whole market, so 1.0 is already optimistic.
const DEPTH_FILL_RATIO = 1.0;
const MAX_DEPTH_AGE_MS = 10_000;

function fullSymbol(symbol, exchange) {
  return symbol.includes(':') ? symbol : `${(exchange || 'NSE').toUpperCase()}:${symbol}`;
}

function segmentFor(exchange) {
  return ['NFO', 'BFO', 'CDS', 'MCX'].includes((exchange || '').toUpperCase())
    ? 'FNO' : 'EQUITY';
}

// ── Book retrieval ──────────────────────────────────────────────
async function getBook(symbol, exchange) {
  const key = fullSymbol(symbol, exchange);

  try {
    const ticker = require('./kiteTicker');
    if (!ticker.symbolToken.has(key)) await ticker.subscribe([key], { full: true });
  } catch { /* REST path below still works */ }

  let tick = await tickCache.getTick(key);
  const stale = !tick || (Date.now() - (tick.updatedAt || 0)) > MAX_DEPTH_AGE_MS;
  if (stale || !tick?.depth) {
    try {
      const { ticks } = await marketDataService.getQuotesSmart([key]);
      if (ticks[key]) tick = ticks[key];
    } catch (e) {
      logger.warn('executionService.getBook: quote fetch failed for ' + key + ': ' + e.message);
    }
  }
  if (!tick) return null;

  const buy  = (tick.depth?.buy  || []).filter(l => l.price > 0 && l.quantity > 0);
  const sell = (tick.depth?.sell || []).filter(l => l.price > 0 && l.quantity > 0);

  // Some instruments stream without depth. Synthesise one level from
  // best bid/ask so they behave sanely instead of never filling.
  if (!buy.length  && tick.bid > 0) buy.push({ price: tick.bid, quantity: tick.bidQty || 0 });
  if (!sell.length && tick.ask > 0) sell.push({ price: tick.ask, quantity: tick.askQty || 0 });

  return {
    symbol: key, ltp: tick.ltp || 0,
    buy:  buy.sort((a, b) => b.price - a.price),    // best bid first
    sell: sell.sort((a, b) => a.price - b.price),   // best ask first
    upperCircuit: tick.upperCircuit || 0,
    lowerCircuit: tick.lowerCircuit || 0,
    age: Date.now() - (tick.updatedAt || 0),
  };
}

// ── The matcher ─────────────────────────────────────────────────
// Pure: reports what WOULD fill, touches no database. The caller runs
// it inside its own transaction.
function matchAgainstBook(book, side, qty, limitPrice) {
  if (!book) return { fills: [], filledQty: 0, remaining: qty, reason: 'No live market data' };

  const levels = side === 'BUY' ? book.sell : book.buy;
  if (!levels.length) {
    return { fills: [], filledQty: 0, remaining: qty,
      reason: side === 'BUY' ? 'No sell orders available right now'
                             : 'No buy orders available right now' };
  }

  const fills = [];
  let remaining = qty;

  for (let i = 0; i < levels.length && remaining > 0; i++) {
    const lvl = levels[i];
    // The price test. The whole point: a BUY never pays above its
    // limit, a SELL never accepts below it. Levels only get worse, so
    // the first failure ends the walk.
    if (limitPrice != null) {
      if (side === 'BUY'  && lvl.price > limitPrice) break;
      if (side === 'SELL' && lvl.price < limitPrice) break;
    }
    const available = Math.floor(lvl.quantity * DEPTH_FILL_RATIO);
    if (available <= 0) continue;
    const take = Math.min(remaining, available);
    fills.push({ qty: take, price: lvl.price, level: i + 1 });
    remaining -= take;
  }

  const filledQty = qty - remaining;
  let reason = null;
  if (filledQty === 0) {
    const best = levels[0].price;
    reason = side === 'BUY'
      ? `No sellers at or below Rs.${limitPrice?.toFixed(2)}. Best offer Rs.${best.toFixed(2)}.`
      : `No buyers at or above Rs.${limitPrice?.toFixed(2)}. Best bid Rs.${best.toFixed(2)}.`;
  } else if (remaining > 0) {
    reason = `Only ${filledQty} of ${qty} could fill at your price. The rest stays open.`;
  }
  return { fills, filledQty, remaining, reason };
}

function vwap(fills) {
  const q = fills.reduce((s, f) => s + f.qty, 0);
  return q ? fills.reduce((s, f) => s + f.qty * f.price, 0) / q : 0;
}

// A MARKET order is bounded by the circuit band, as on a real exchange.
function marketBound(book, side) {
  if (side === 'BUY')  return book.upperCircuit > 0 ? book.upperCircuit : null;
  return book.lowerCircuit > 0 ? book.lowerCircuit : null;
}

// ── Pending order retry pass ────────────────────────────────────
// A resting LIMIT order fills the moment the market reaches it, which
// is how a real one behaves.
async function processPendingOrders() {
  if (!getMarketStatus().isOpen) return;
  let orders;
  try {
    const [rows] = await db.pool.query(
      "SELECT * FROM app_orders WHERE status IN ('PENDING','PARTIAL') ORDER BY placed_at ASC LIMIT 200");
    orders = rows;
  } catch (e) {
    logger.error('processPendingOrders query: ' + e.message);
    return;
  }
  for (const o of orders) {
    try { await attemptFill(o); }
    catch (e) { logger.warn(`processPendingOrders: order ${o.id} — ${e.message}`); }
  }
}

async function attemptFill(order) {
  const remaining = order.qty - order.filled_qty;
  if (remaining <= 0) return;

  const book = await getBook(order.symbol, order.exchange);
  if (!book) return;

  const isMarket = order.price_type === 'MARKET';
  const limit = isMarket ? marketBound(book, order.order_type) : parseFloat(order.price);
  const { fills, filledQty } = matchAgainstBook(book, order.order_type, remaining, limit);
  if (!filledQty) return;

  const conn = await db.pool.getConnection();
  try {
    await conn.beginTransaction();

    // Re-read under lock: another pass or a cancel may have moved it.
    const [[fresh]] = await conn.query('SELECT * FROM app_orders WHERE id=? FOR UPDATE', [order.id]);
    if (!fresh || !['PENDING', 'PARTIAL'].includes(fresh.status)) {
      await conn.rollback(); conn.release(); return;
    }
    const stillLeft = fresh.qty - fresh.filled_qty;
    if (stillLeft <= 0) { await conn.rollback(); conn.release(); return; }

    // Trim to what is genuinely still outstanding.
    const trimmed = [];
    let budget = stillLeft;
    for (const f of fills) {
      if (budget <= 0) break;
      const take = Math.min(f.qty, budget);
      trimmed.push({ ...f, qty: take });
      budget -= take;
    }

    const qty   = trimmed.reduce((s, f) => s + f.qty, 0);
    const value = trimmed.reduce((s, f) => s + f.qty * f.price, 0);
    const avg   = value / qty;

    for (const f of trimmed) {
      await conn.query(
        'INSERT INTO app_trades (order_id, user_id, symbol, exchange, side, qty, price, depth_level) ' +
        'VALUES (?,?,?,?,?,?,?,?)',
        [fresh.id, fresh.user_id, fresh.symbol, fresh.exchange,
         fresh.order_type, f.qty, f.price, f.level]);
    }

    // Margin actually consumed per unit, from what was blocked.
    const marginPerUnit = fresh.qty > 0
      ? parseFloat(fresh.blocked_amount || 0) / fresh.qty : 0;

    const meta = await contractMeta(fresh);
    const posRes = await positionService.applyFill(conn, {
      userId: fresh.user_id, symbol: fresh.symbol, exchange: fresh.exchange,
      segment: fresh.segment, product: fresh.product, name: fresh.name,
      side: fresh.order_type, qty, price: avg, marginPerUnit, meta,
    });

    // Money movement. An opening trade consumed blocked margin; a
    // closing trade returns margin plus realised P&L to the wallet.
    let blocked = parseFloat(fresh.blocked_amount || 0);
    const consumed = Math.min(blocked, marginPerUnit * qty);
    blocked -= consumed;

    if (posRes.closedQty > 0) {
      const credit = posRes.realisedPnl;
      if (Math.abs(credit) > 0.0001) {
        await conn.query('UPDATE app_wallet SET balance = balance + ? WHERE user_id=?',
          [credit, fresh.user_id]);
        await conn.query(
          'INSERT INTO wallet_transactions (user_id, type, amount, note, done_by) VALUES (?,?,?,?,?)',
          [fresh.user_id, credit >= 0 ? 'credit' : 'debit', Math.abs(credit),
           `Realised P&L on ${fresh.symbol}: Rs.${credit.toFixed(2)}`, 'system']);
      }
    }

    const newFilled = fresh.filled_qty + qty;
    const prevValue = parseFloat(fresh.avg_price || 0) * fresh.filled_qty;
    const newAvg    = newFilled > 0 ? (prevValue + value) / newFilled : 0;
    const done      = newFilled >= fresh.qty;

    // Release margin blocked at the limit but not needed at the better
    // price we actually filled at, and anything left over on completion.
    if (done && blocked > 0.0001) {
      await conn.query('UPDATE app_wallet SET balance = balance + ? WHERE user_id=?',
        [blocked, fresh.user_id]);
      await conn.query(
        'INSERT INTO wallet_transactions (user_id, type, amount, note, done_by) VALUES (?,?,?,?,?)',
        [fresh.user_id, 'credit', blocked,
         `Released unused margin on order #${fresh.id}`, 'system']);
      blocked = 0;
    }

    await conn.query(
      'UPDATE app_orders SET filled_qty=?, avg_price=?, blocked_amount=?, status=? WHERE id=?',
      [newFilled, newAvg.toFixed(4), blocked.toFixed(4),
       done ? 'EXECUTED' : 'PARTIAL', fresh.id]);

    await conn.commit(); conn.release();
    logger.info(`order ${fresh.id}: filled ${qty} @ avg Rs.${avg.toFixed(2)} ` +
                `(${newFilled}/${fresh.qty}) across ${trimmed.length} level(s)`);
  } catch (e) {
    try { await conn.rollback(); } catch {}
    conn.release();
    throw e;
  }
}

// Expiry / strike / lot size for an F&O contract, so the position row
// carries what expiry settlement will need later.
async function contractMeta(order) {
  if (order.segment !== 'FNO') return {};
  try {
    const [[row]] = await db.pool.query(
      "SELECT expiry, lot_size, instrument_type, strike FROM instruments " +
      "WHERE tradingsymbol = ? AND exchange IN ('NFO','BFO') LIMIT 1",
      [order.symbol]);
    if (!row) return {};
    return {
      expiry: row.expiry, lotSize: row.lot_size,
      instrumentType: row.instrument_type, strike: row.strike,
    };
  } catch { return {}; }
}

// ── Matcher loop ────────────────────────────────────────────────
let matcherTimer = null;
function startMatcher(intervalMs = 2000) {
  if (matcherTimer) return;
  matcherTimer = setInterval(() => {
    processPendingOrders().catch(e => logger.error('matcher pass: ' + e.message));
  }, intervalMs);
  logger.info(`order matcher started (every ${intervalMs}ms)`);
}
function stopMatcher() { clearInterval(matcherTimer); matcherTimer = null; }

module.exports = {
  getBook, matchAgainstBook, attemptFill, processPendingOrders,
  startMatcher, stopMatcher, vwap, fullSymbol, segmentFor, marketBound,
  contractMeta,
};
