// marginService.js — NEW. Item 3.
//
// Decides how much money to block for an order. Before this, `product`
// was stored on every order and then completely ignored: DELIVERY,
// INTRADAY and MTF all debited the full trade value, so there was no
// leverage of any kind and the three products were indistinguishable.
//
// Rules, as specified:
//   EQUITY  DELIVERY  1x    full value, settles T+1
//   EQUITY  INTRADAY  4x    25% blocked, auto squared off at 15:15
//   EQUITY  MTF       4x    25% blocked, carried forward
//   FNO     BUY       1x    full premium — no leverage on options
//   FNO     SHORT     margin % of notional (approximation, see below)
//
// On the F&O short margin: a real broker computes SPAN + exposure from
// the exchange's daily risk file. That file is not available here, so
// short margin is a flat configurable percentage of notional, defaulting
// to 15%. It is an approximation and is deliberately conservative. If
// you later wire in a SPAN source, replace shortMarginPct() only —
// nothing else in this file needs to change.

const settings   = require('../utils/settings');
const { logger } = require('../config/logger');

const DEFAULTS = {
  equity_intraday_leverage: 4,
  equity_mtf_leverage:      4,
  fno_buy_leverage:         1,
  fno_short_margin_pct:     15,
};

async function num(key) {
  try { return await settings.getNumber(key, DEFAULTS[key]); }
  catch { return DEFAULTS[key]; }
}

function normalizeProduct(product, segment) {
  const p = String(product || 'DELIVERY').toUpperCase();
  // MIS/CNC/NRML aliases, in case the app sends broker-style names.
  if (p === 'MIS') return 'INTRADAY';
  if (p === 'CNC') return 'DELIVERY';
  if (p === 'NRML') return segment === 'FNO' ? 'DELIVERY' : 'DELIVERY';
  if (!['DELIVERY', 'INTRADAY', 'MTF'].includes(p)) return 'DELIVERY';
  return p;
}

/**
 * Effective leverage for a BUY. Returns 1 when no leverage applies.
 * F&O never gets leverage on a buy: an option buyer pays the full
 * premium, which is already its maximum loss, so leveraging it would
 * let a user lose more than they staked.
 */
async function leverageFor({ segment, product }) {
  if (segment === 'FNO') return await num('fno_buy_leverage');   // 1
  if (product === 'INTRADAY') return await num('equity_intraday_leverage');
  if (product === 'MTF')      return await num('equity_mtf_leverage');
  return 1;                                                      // DELIVERY
}

async function shortMarginPct() {
  const pct = await num('fno_short_margin_pct');
  return Math.min(100, Math.max(1, pct)) / 100;
}

/**
 * How much to block for an order.
 *
 * side        'BUY' | 'SELL'
 * segment     'EQUITY' | 'FNO'
 * product     'DELIVERY' | 'INTRADAY' | 'MTF'
 * qty         units (shares, or total option quantity — not lots)
 * price       worst-case price per unit (the limit price, or market + buffer)
 * isOpening   true when this trade OPENS or ADDS to exposure; a SELL
 *             that closes an existing long needs no margin at all.
 */
async function requiredMargin({ side, segment, product, qty, price, isOpening }) {
  const notional = qty * price;

  // Closing an existing position releases margin rather than needing it.
  if (!isOpening) {
    return { amount: 0, leverage: 1, notional, basis: 'closing trade — no margin required' };
  }

  if (side === 'SELL') {
    // Opening a SHORT.
    if (segment === 'FNO') {
      const pct = await shortMarginPct();
      return {
        amount:   notional * pct,
        leverage: +(1 / pct).toFixed(2),
        notional,
        basis:    `F&O short margin ${(pct * 100).toFixed(0)}% of notional ` +
                  `(approximation of SPAN + exposure)`,
      };
    }
    // Equity short selling is intraday-only in India — you cannot
    // deliver shares you do not own. Blocked at the same 4x as a long.
    if (product !== 'INTRADAY') {
      return {
        amount: notional, leverage: 1, notional, blocked: true,
        basis: 'Short selling equity is only allowed as an INTRADAY product',
      };
    }
    const lev = await num('equity_intraday_leverage');
    return {
      amount: notional / lev, leverage: lev, notional,
      basis: `Equity intraday short, ${lev}x`,
    };
  }

  // Opening a LONG.
  const lev = await leverageFor({ segment, product });
  return {
    amount:   notional / lev,
    leverage: lev,
    notional,
    basis: segment === 'FNO'
      ? 'F&O buy — full premium, no leverage'
      : lev > 1 ? `Equity ${product.toLowerCase()}, ${lev}x` : 'Equity delivery, full value',
  };
}

/**
 * Validates the product against the instrument. Catches the combinations
 * that do not exist in a real market before any money moves.
 */
function validateProduct({ segment, product, side }) {
  if (segment === 'FNO' && product === 'MTF') {
    return 'MTF is not available for F&O contracts';
  }
  if (segment === 'EQUITY' && side === 'SELL' && product === 'MTF') {
    return 'MTF positions must be sold as MTF, not short sold';
  }
  return null;
}

/** Human-readable buying power for the order screen. */
async function buyingPower(balance, { segment, product }) {
  const lev = await leverageFor({ segment, product });
  return { available: balance, leverage: lev, buyingPower: balance * lev };
}

module.exports = {
  normalizeProduct,
  leverageFor,
  requiredMargin,
  validateProduct,
  buyingPower,
  shortMarginPct,
};
