// razorpayService.js
//
// CHANGED: keys resolve from app_settings first, falling back to .env,
// so the admin can rotate them without SSH and a restart (item 10).
// Two structural fixes that made that possible: the client was memoized
// forever, so even an .env change needed a restart; and verifySignature
// read process.env directly, so a DB-stored secret would have been used
// to create orders but ignored when verifying them — every payment
// would have failed. Both now resolve through one path.
//
// SECURITY: the secret is stored in plaintext in app_settings, as it is
// in .env today. Keep phpMyAdmin off the public internet.
const crypto     = require('crypto');
const Razorpay   = require('razorpay');
const settings   = require('../utils/settings');
const { logger } = require('../config/logger');

let client = null, clientKeyId = null, clientSecret = null;

async function getCredentials() {
  let keyId, keySecret;
  try {
    const all = await settings.getAll();
    keyId     = (all.razorpay_key_id     || '').trim();
    keySecret = (all.razorpay_key_secret || '').trim();
  } catch {}
  if (!keyId)     keyId     = (process.env.RAZORPAY_KEY_ID     || '').trim();
  if (!keySecret) keySecret = (process.env.RAZORPAY_KEY_SECRET || '').trim();
  if (!keyId || !keySecret) {
    throw new Error('Razorpay keys are not configured. Set them in Admin -> Configuration, ' +
                    'or as RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET in .env');
  }
  return { keyId, keySecret };
}

async function getClient() {
  const { keyId, keySecret } = await getCredentials();
  if (client && clientKeyId === keyId && clientSecret === keySecret) return client;
  client = new Razorpay({ key_id: keyId, key_secret: keySecret });
  clientKeyId = keyId; clientSecret = keySecret;
  logger.info('razorpay: client (re)initialised for key ' + keyId.slice(0, 12) + '...');
  return client;
}

async function getPublicKeyId() { return (await getCredentials()).keyId; }
function invalidate() { client = null; clientKeyId = null; clientSecret = null; }

async function createOrder(amountRupees, receiptId) {
  const c = await getClient();
  return c.orders.create({
    amount: Math.round(amountRupees * 100), currency: 'INR', receipt: receiptId,
  });
}

function safeEqual(expected, given) {
  const a = Buffer.from(expected), b = Buffer.from(String(given || ''));
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

// NOTE: async now. wallet.js must await it — see README "Manual edits".
async function verifySignature(orderId, paymentId, signature) {
  const { keySecret } = await getCredentials();
  const expected = crypto.createHmac('sha256', keySecret)
    .update(orderId + '|' + paymentId).digest('hex');
  return safeEqual(expected, signature);
}

async function verifyWebhookSignature(rawBody, signature) {
  let secret = '';
  try { secret = ((await settings.getAll()).razorpay_webhook_secret || '').trim(); } catch {}
  if (!secret) secret = (process.env.RAZORPAY_WEBHOOK_SECRET || '').trim();
  if (!secret) {
    logger.warn('razorpay: webhook secret not set — signature check skipped');
    return false;
  }
  const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
  return safeEqual(expected, signature);
}

module.exports = {
  createOrder, verifySignature, verifyWebhookSignature,
  getPublicKeyId, getCredentials, invalidate,
};
